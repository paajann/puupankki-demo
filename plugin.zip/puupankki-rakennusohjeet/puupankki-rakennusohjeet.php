<?php
/*
Plugin Name: Puupankki – Rakennusohjeet
Description: Lisäosa myytävien rakennusohjeiden määrittelyyn ja näyttämiseen. Sisältää artikkelityypin Rakennusohjeet, ohjekategoriat, lyhytkoodin [ohjekauppa] ja Suositellut ohjeet -vimpaimen.
Version: 1.1
Author: Anne-Maria Pääjänen
*/

// Estetään tiedoston suora avaaminen selaimessa
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function pp_rakennusohje_post_type() {
    register_post_type( 'rakennusohje', [
        'labels' => [
            'name'          => 'Rakennusohjeet',
            'singular_name' => 'Rakennusohje',
            'add_new'       => 'Lisää uusi',
            'add_new_item'  => 'Lisää uusi rakennusohje',
            'edit_item'     => 'Muokkaa rakennusohjetta',
            'all_items'     => 'Kaikki rakennusohjeet',
            'not_found'     => 'Rakennusohjeita ei löytynyt',
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'rakennusohjeet' ],
        'menu_icon'    => 'dashicons-hammer',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
        'show_in_rest' => true,
    ] );
}
add_action( 'init', 'pp_rakennusohje_post_type' );

// Lisäosan muut osat: ohjekategoria, ohjekortti, lyhytkoodi ja vimpain
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-ohjekategoria.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-ohjekortti.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-lyhytkoodi.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-vimpain.php';

// Kestolinkit päivittyvät automaattisesti, kun lisäosa otetaan käyttöön
function pp_rakennusohjeet_aktivointi() {
    pp_rakennusohje_post_type();
    pp_ohjekategoria_taxonomy();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'pp_rakennusohjeet_aktivointi' );

// Lisäosan oma CSS julkiselle puolelle
function pp_rakennusohjeet_css() {
    wp_enqueue_style( 'pp-rakennusohjeet', plugin_dir_url( __FILE__ ) . 'css/pp-rakennusohjeet.css', [], '1.7' );
}
add_action( 'wp_enqueue_scripts', 'pp_rakennusohjeet_css' );

// Ohjesivu hallintavalikkoon: miten lyhytkoodia ja vimpainta käytetään
function pp_rakennusohjeet_ohjesivu() {
    add_submenu_page( 'edit.php?post_type=rakennusohje', 'Käyttöohje', 'Käyttöohje', 'manage_options', 'pp-kayttoohje', 'pp_rakennusohjeet_ohjesivu_html' );
}
add_action( 'admin_menu', 'pp_rakennusohjeet_ohjesivu' );

function pp_rakennusohjeet_ohjesivu_html() {
    echo '<div class="wrap">';
    echo '<h1>Rakennusohjeet – käyttöohje</h1>';
    echo '<p>Lisää sivulle lyhytkoodi <code>[ohjekauppa]</code> näyttääksesi kaikki rakennusohjeet, ';
    echo 'tai <code>[ohjekauppa kategoria="kategorian-polkutunnus"]</code> näyttääksesi vain tietyn ohjekategorian ohjeet.</p>';
    echo '<p>Vimpain <strong>Puupankki: Suositellut ohjeet</strong> löytyy kohdasta Ulkoasu → Vimpaimet. ';
    echo 'Rakennusohjeen sivulla se näyttää samankaltaisia ohjeita, muualla uusimmat ohjeet.</p>';
    echo '</div>';
}

// Vaativuustasot yhdessä paikassa
function pp_ohje_vaativuustasot() {
    return [
        'helppo'    => 'Helppo',
        'keskitaso' => 'Keskitaso',
        'vaativa'   => 'Vaativa',
    ];
}

// Tietolaatikko muokkausnäkymään
function pp_ohje_meta_box() {
    add_meta_box( 'pp_ohjeen_tiedot', 'Ohjeen tiedot', 'pp_ohje_meta_box_html', 'rakennusohje', 'side' );
}
add_action( 'add_meta_boxes', 'pp_ohje_meta_box' );

function pp_ohje_meta_box_html( $post ) {
    wp_nonce_field( 'pp_ohje_tallennus', 'pp_ohje_nonce' );

    $hinta     = get_post_meta( $post->ID, '_pp_hinta', true );
    $vaativuus = get_post_meta( $post->ID, '_pp_vaativuus', true );
    $tyoaika   = get_post_meta( $post->ID, '_pp_tyoaika', true );
    $puulaji   = get_post_meta( $post->ID, '_pp_puulaji', true );

    $puulajit = post_type_exists( 'puulaji' )
        ? get_posts( [ 'post_type' => 'puulaji', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ] )
        : [];
    ?>
    <p>
        <label for="pp_hinta">Hinta (€)</label><br>
        <input type="number" id="pp_hinta" name="pp_hinta" min="0" step="0.01" value="<?php echo esc_attr( $hinta ); ?>">
    </p>
    <p>
        <label for="pp_vaativuus">Vaativuustaso</label><br>
        <select id="pp_vaativuus" name="pp_vaativuus">
            <option value="">– Valitse –</option>
            <?php foreach ( pp_ohje_vaativuustasot() as $arvo => $nimi ) : ?>
                <option value="<?php echo esc_attr( $arvo ); ?>" <?php selected( $vaativuus, $arvo ); ?>><?php echo esc_html( $nimi ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p>
        <label for="pp_tyoaika">Työaika</label><br>
        <input type="text" id="pp_tyoaika" name="pp_tyoaika" placeholder="esim. n. 3 tuntia" value="<?php echo esc_attr( $tyoaika ); ?>">
    </p>
    <?php if ( $puulajit ) : ?>
    <p>
        <label for="pp_puulaji">Suositeltu puulaji</label><br>
        <select id="pp_puulaji" name="pp_puulaji">
            <option value="">– Ei valittu –</option>
            <?php foreach ( $puulajit as $puu ) : ?>
                <option value="<?php echo esc_attr( $puu->ID ); ?>" <?php selected( $puulaji, $puu->ID ); ?>><?php echo esc_html( $puu->post_title ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <?php endif;
}

// Tallennus
function pp_ohje_tallenna( $post_id ) {
    if ( ! isset( $_POST['pp_ohje_nonce'] ) || ! wp_verify_nonce( $_POST['pp_ohje_nonce'], 'pp_ohje_tallennus' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $hinta = isset( $_POST['pp_hinta'] ) ? str_replace( ',', '.', $_POST['pp_hinta'] ) : '';
    $kentat = [
        '_pp_hinta'     => $hinta !== '' ? (string) floatval( $hinta ) : '',
        '_pp_vaativuus' => array_key_exists( $_POST['pp_vaativuus'] ?? '', pp_ohje_vaativuustasot() ) ? $_POST['pp_vaativuus'] : '',
        '_pp_tyoaika'   => sanitize_text_field( $_POST['pp_tyoaika'] ?? '' ),
        '_pp_puulaji'   => absint( $_POST['pp_puulaji'] ?? 0 ) ?: '',
    ];

    foreach ( $kentat as $avain => $arvo ) {
        if ( $arvo === '' ) {
            delete_post_meta( $post_id, $avain );
        } else {
            update_post_meta( $post_id, $avain, $arvo );
        }
    }
}
add_action( 'save_post_rakennusohje', 'pp_ohje_tallenna' );

// Tiedot näkyviin ohjeen sivulle sisällön yläpuolelle
function pp_ohje_tiedot_sisaltoon( $content ) {
    if ( ! is_singular( 'rakennusohje' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    $id        = get_the_ID();
    $hinta     = get_post_meta( $id, '_pp_hinta', true );
    $vaativuus = get_post_meta( $id, '_pp_vaativuus', true );
    $tyoaika   = get_post_meta( $id, '_pp_tyoaika', true );
    $puulaji   = get_post_meta( $id, '_pp_puulaji', true );
    $tasot     = pp_ohje_vaativuustasot();

    $rivit = [];
    if ( $hinta !== '' ) {
        $rivit['Hinta'] = pp_ohje_hinta_teksti( $hinta );
    }
    if ( $vaativuus && isset( $tasot[ $vaativuus ] ) ) {
        $rivit['Vaativuustaso'] = esc_html( $tasot[ $vaativuus ] );
    }
    if ( $tyoaika ) {
        $rivit['Työaika'] = esc_html( $tyoaika );
    }
    if ( $puulaji && get_post_status( $puulaji ) === 'publish' ) {
        $rivit['Suositeltu puulaji'] = '<a href="' . esc_url( get_permalink( $puulaji ) ) . '">' . esc_html( get_the_title( $puulaji ) ) . '</a>';
    }

    if ( ! $rivit ) {
        return $content;
    }

    $html = '<dl class="ohje-tiedot">';
    foreach ( $rivit as $otsikko => $arvo ) {
        $html .= '<div><dt>' . esc_html( $otsikko ) . '</dt><dd>' . $arvo . '</dd></div>';
    }
    $html .= '</dl>';

    return $html . $content;
}
add_filter( 'the_content', 'pp_ohje_tiedot_sisaltoon' );