<?php
/*
Plugin Name: Puupankki – Rakennusohjeet
Description: Lisäosa myytävien rakennusohjeiden määrittelyyn ja näyttämiseen. Sisältää artikkelityypin Rakennusohjeet, ohjekategoriat, lyhytkoodin [ohjekauppa] ja Suositellut ohjeet -vimpaimen.
Version: 1.1
Author: Anne-Maria Pääjänen
*/

// Stop the file from being opened directly in a browser
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function pp_building_guide_post_type() {
    register_post_type( 'rakennusohje', [
        'labels' => [
            'name'          => 'Rakennusohjeet',
            'singular_name' => 'Rakennusohje',
            'add_new'       => 'Lisää uusi',
            'add_new_item'  => 'Lisää uusi rakennusohje',
            'edit_item'     => 'Muokkaa rakennusohjetta',
            'all_items'     => 'Kaikki rakennusohjeet',
            'not_found'     => 'Rakennusohjeita ei löytynyt',
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'rakennusohjeet' ],
        'menu_icon'    => 'dashicons-hammer',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
        'show_in_rest' => true,
    ] );
}
add_action( 'init', 'pp_building_guide_post_type' );

// The rest of the plugin: guide category, guide card, shortcode and widget
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-guide-category.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-guide-card.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-shortcode.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/pp-widget.php';

// Permalinks refresh automatically when the plugin is activated
function pp_building_guides_activate() {
    pp_building_guide_post_type();
    pp_guide_category_taxonomy();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'pp_building_guides_activate' );

// The plugin's own stylesheet, front end only
function pp_building_guides_css() {
    wp_enqueue_style( 'pp-rakennusohjeet', plugin_dir_url( __FILE__ ) . 'css/pp-building-guides.css', [], '1.7' );
}
add_action( 'wp_enqueue_scripts', 'pp_building_guides_css' );

// Help page in the admin menu: how to use the shortcode and the widget
function pp_building_guides_help_page() {
    add_submenu_page( 'edit.php?post_type=rakennusohje', 'Käyttöohje', 'Käyttöohje', 'manage_options', 'pp-kayttoohje', 'pp_building_guides_help_page_html' );
}
add_action( 'admin_menu', 'pp_building_guides_help_page' );

function pp_building_guides_help_page_html() {
    echo '<div class="wrap">';
    echo '<h1>Rakennusohjeet – käyttöohje</h1>';
    echo '<p>Lisää sivulle lyhytkoodi <code>[ohjekauppa]</code> näyttääksesi kaikki rakennusohjeet, ';
    echo 'tai <code>[ohjekauppa kategoria="kategorian-polkutunnus"]</code> näyttääksesi vain tietyn ohjekategorian ohjeet.</p>';
    echo '<p>Vimpain <strong>Puupankki: Suositellut ohjeet</strong> löytyy kohdasta Ulkoasu → Vimpaimet. ';
    echo 'Rakennusohjeen sivulla se näyttää samankaltaisia ohjeita, muualla uusimmat ohjeet.</p>';
    echo '</div>';
}

// Difficulty levels, defined in one place
function pp_guide_difficulty_levels() {
    return [
        'helppo'    => 'Helppo',
        'keskitaso' => 'Keskitaso',
        'vaativa'   => 'Vaativa',
    ];
}

// Meta box for the edit screen
function pp_guide_meta_box() {
    add_meta_box( 'pp_ohjeen_tiedot', 'Ohjeen tiedot', 'pp_guide_meta_box_html', 'rakennusohje', 'side' );
}
add_action( 'add_meta_boxes', 'pp_guide_meta_box' );

function pp_guide_meta_box_html( $post ) {
    wp_nonce_field( 'pp_ohje_tallennus', 'pp_ohje_nonce' );

    $price     = get_post_meta( $post->ID, '_pp_hinta', true );
    $difficulty = get_post_meta( $post->ID, '_pp_vaativuus', true );
    $work_time   = get_post_meta( $post->ID, '_pp_tyoaika', true );
    $species_id   = get_post_meta( $post->ID, '_pp_puulaji', true );

    $species_list = post_type_exists( 'puulaji' )
        ? get_posts( [ 'post_type' => 'puulaji', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ] )
        : [];
    ?>
    <p>
        <label for="pp_hinta">Hinta (€)</label><br>
        <input type="number" id="pp_hinta" name="pp_hinta" min="0" step="0.01" value="<?php echo esc_attr( $price ); ?>">
    </p>
    <p>
        <label for="pp_vaativuus">Vaativuustaso</label><br>
        <select id="pp_vaativuus" name="pp_vaativuus">
            <option value="">– Valitse –</option>
            <?php foreach ( pp_guide_difficulty_levels() as $value => $name ) : ?>
                <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $difficulty, $value ); ?>><?php echo esc_html( $name ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p>
        <label for="pp_tyoaika">Työaika</label><br>
        <input type="text" id="pp_tyoaika" name="pp_tyoaika" placeholder="esim. n. 3 tuntia" value="<?php echo esc_attr( $work_time ); ?>">
    </p>
    <?php if ( $species_list ) : ?>
    <p>
        <label for="pp_puulaji">Suositeltu puulaji</label><br>
        <select id="pp_puulaji" name="pp_puulaji">
            <option value="">– Ei valittu –</option>
            <?php foreach ( $species_list as $species ) : ?>
                <option value="<?php echo esc_attr( $species->ID ); ?>" <?php selected( $species_id, $species->ID ); ?>><?php echo esc_html( $species->post_title ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <?php endif;
}

// Tallennus
function pp_guide_save( $post_id ) {
    if ( ! isset( $_POST['pp_ohje_nonce'] ) || ! wp_verify_nonce( $_POST['pp_ohje_nonce'], 'pp_ohje_tallennus' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $price = isset( $_POST['pp_hinta'] ) ? str_replace( ',', '.', $_POST['pp_hinta'] ) : '';
    $fields = [
        '_pp_hinta'     => $price !== '' ? (string) floatval( $price ) : '',
        '_pp_vaativuus' => array_key_exists( $_POST['pp_vaativuus'] ?? '', pp_guide_difficulty_levels() ) ? $_POST['pp_vaativuus'] : '',
        '_pp_tyoaika'   => sanitize_text_field( $_POST['pp_tyoaika'] ?? '' ),
        '_pp_puulaji'   => absint( $_POST['pp_puulaji'] ?? 0 ) ?: '',
    ];

    foreach ( $fields as $key => $value ) {
        if ( $value === '' ) {
            delete_post_meta( $post_id, $key );
        } else {
            update_post_meta( $post_id, $key, $value );
        }
    }
}
add_action( 'save_post_rakennusohje', 'pp_guide_save' );

// Show the details above the content on a guide page
function pp_guide_details_before_content( $content ) {
    if ( ! is_singular( 'rakennusohje' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    $id        = get_the_ID();
    $price     = get_post_meta( $id, '_pp_hinta', true );
    $difficulty = get_post_meta( $id, '_pp_vaativuus', true );
    $work_time   = get_post_meta( $id, '_pp_tyoaika', true );
    $species_id   = get_post_meta( $id, '_pp_puulaji', true );
    $levels     = pp_guide_difficulty_levels();

    $rows = [];
    if ( $price !== '' ) {
        $rows['Hinta'] = pp_guide_price_text( $price );
    }
    if ( $difficulty && isset( $levels[ $difficulty ] ) ) {
        $rows['Vaativuustaso'] = esc_html( $levels[ $difficulty ] );
    }
    if ( $work_time ) {
        $rows['Työaika'] = esc_html( $work_time );
    }
    if ( $species_id && get_post_status( $species_id ) === 'publish' ) {
        $rows['Suositeltu puulaji'] = '<a href="' . esc_url( get_permalink( $species_id ) ) . '">' . esc_html( get_the_title( $species_id ) ) . '</a>';
    }

    if ( ! $rows ) {
        return $content;
    }

    $html = '<dl class="guide-details">';
    foreach ( $rows as $title => $value ) {
        $html .= '<div><dt>' . esc_html( $title ) . '</dt><dd>' . $value . '</dd></div>';
    }
    $html .= '</dl>';

    return $html . $content;
}
add_filter( 'the_content', 'pp_guide_details_before_content' );