<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Price as text: 0 € reads "Ilmainen", anything else as "4,90 €".
// Used by both the card and the guide page, so the rule lives in one place.
function pp_guide_price_text( $price ) {
    if ( (float) $price == 0 ) {
        return 'Ilmainen';
    }
    return esc_html( number_format_i18n( (float) $price, 2 ) . ' €' );
}

// HTML card for a single building guide. The same function draws the card
// for both the shortcode and the widget, so the markup is not duplicated.
// $show_excerpt: true in the shortcode (excerpt shown), false in the widget.
function pp_guide_card( $id, $show_excerpt = true ) {
    $price     = get_post_meta( $id, '_pp_hinta', true );
    $difficulty = get_post_meta( $id, '_pp_vaativuus', true );
    $work_time   = get_post_meta( $id, '_pp_tyoaika', true );
    $species_id   = get_post_meta( $id, '_pp_puulaji', true );
    $levels     = pp_guide_difficulty_levels();

    // Kaikki tietokannasta tuleva teksti "escapetaan" ulos tulostettaessa
    $html  = '<article class="pp-guide">';
    $html .= '<a class="pp-guide__link" href="' . esc_url( get_permalink( $id ) ) . '">';
    if ( has_post_thumbnail( $id ) ) {
        $html .= get_the_post_thumbnail( $id, 'medium', [ 'class' => 'pp-guide__image' ] );
    }
    $html .= '<h3 class="pp-guide__title">' . esc_html( get_the_title( $id ) ) . '</h3>';
    $html .= '</a>';

    $html .= '<ul class="pp-guide__details">';
    if ( $price !== '' ) {
        $html .= '<li class="pp-guide__price">' . pp_guide_price_text( $price ) . '</li>';
    }
    if ( $difficulty && isset( $levels[ $difficulty ] ) ) {
        $html .= '<li>Vaativuustaso: ' . esc_html( $levels[ $difficulty ] ) . '</li>';
    }
    if ( $work_time ) {
        $html .= '<li>Työaika: ' . esc_html( $work_time ) . '</li>';
    }
    if ( $species_id && get_post_status( $species_id ) === 'publish' ) {
        $html .= '<li>Puulaji: ' . esc_html( get_the_title( $species_id ) ) . '</li>';
    }
    $html .= '</ul>';

    if ( $show_excerpt && has_excerpt( $id ) ) {
        $html .= '<p class="pp-guide__excerpt">' . esc_html( get_the_excerpt( $id ) ) . '</p>';
    }

    $html .= '</article>';
    return $html;
}