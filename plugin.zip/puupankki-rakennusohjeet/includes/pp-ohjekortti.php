<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Hinta tekstinä: 0 € näytetään sanana "Ilmainen", muuten esim. "4,90 €".
// Sama funktio käytössä kortissa ja ohjesivulla, jotta sääntö on yhdessä paikassa.
function pp_ohje_hinta_teksti( $hinta ) {
    if ( (float) $hinta == 0 ) {
        return 'Ilmainen';
    }
    return esc_html( number_format_i18n( (float) $hinta, 2 ) . ' €' );
}

// Yhden rakennusohjeen HTML-kortti. Sama funktio piirtää kortin sekä
// lyhytkoodissa että vimpaimessa, jotta koodi ei ole kahdessa paikassa.
// $nayta_kuvaus: lyhytkoodissa true (ote näkyy), vimpaimessa false.
function pp_ohje_kortti( $id, $nayta_kuvaus = true ) {
    $hinta     = get_post_meta( $id, '_pp_hinta', true );
    $vaativuus = get_post_meta( $id, '_pp_vaativuus', true );
    $tyoaika   = get_post_meta( $id, '_pp_tyoaika', true );
    $puulaji   = get_post_meta( $id, '_pp_puulaji', true );
    $tasot     = pp_ohje_vaativuustasot();

    // Kaikki tietokannasta tuleva teksti "escapetaan" ulos tulostettaessa
    $html  = '<article class="pp-ohje">';
    $html .= '<a class="pp-ohje__linkki" href="' . esc_url( get_permalink( $id ) ) . '">';
    if ( has_post_thumbnail( $id ) ) {
        $html .= get_the_post_thumbnail( $id, 'medium', [ 'class' => 'pp-ohje__kuva' ] );
    }
    $html .= '<h3 class="pp-ohje__otsikko">' . esc_html( get_the_title( $id ) ) . '</h3>';
    $html .= '</a>';

    $html .= '<ul class="pp-ohje__tiedot">';
    if ( $hinta !== '' ) {
        $html .= '<li class="pp-ohje__hinta">' . pp_ohje_hinta_teksti( $hinta ) . '</li>';
    }
    if ( $vaativuus && isset( $tasot[ $vaativuus ] ) ) {
        $html .= '<li>Vaativuustaso: ' . esc_html( $tasot[ $vaativuus ] ) . '</li>';
    }
    if ( $tyoaika ) {
        $html .= '<li>Työaika: ' . esc_html( $tyoaika ) . '</li>';
    }
    if ( $puulaji && get_post_status( $puulaji ) === 'publish' ) {
        $html .= '<li>Puulaji: ' . esc_html( get_the_title( $puulaji ) ) . '</li>';
    }
    $html .= '</ul>';

    if ( $nayta_kuvaus && has_excerpt( $id ) ) {
        $html .= '<p class="pp-ohje__kuvaus">' . esc_html( get_the_excerpt( $id ) ) . '</p>';
    }

    $html .= '</article>';
    return $html;
}