<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Lyhytkoodi: [ohjekauppa] tai [ohjekauppa kategoria="pihakalusteet"]
function pp_ohjekauppa_lyhytkoodi( $atts ) {
    $atts = shortcode_atts( [
        'kategoria' => '',
    ], $atts );

    $args = [
        'post_type'      => 'rakennusohje',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    // Jos kategoria annettu, rajataan haku siihen
    if ( $atts['kategoria'] !== '' ) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'ohjekategoria',
                'field'    => 'slug',
                'terms'    => sanitize_title( $atts['kategoria'] ),
            ],
        ];
    }

    $haku = new WP_Query( $args );

    $html = '<div class="pp-ohjekauppa">';
    if ( $haku->have_posts() ) {
        while ( $haku->have_posts() ) {
            $haku->the_post();
            $html .= pp_ohje_kortti( get_the_ID(), true );
        }
    } else {
        $html .= '<p>Rakennusohjeita ei löytynyt.</p>';
    }
    $html .= '</div>';

    // Palautetaan WordPressin oma kysely ennalleen, ettei lyhytkoodin haku
    // sotke sivun muuta sisältöä
    wp_reset_postdata();

    return $html;
}
add_shortcode( 'ohjekauppa', 'pp_ohjekauppa_lyhytkoodi' );
