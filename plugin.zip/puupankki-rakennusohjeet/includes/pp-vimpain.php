<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Vimpain: Suositellut ohjeet
// - Rakennusohjeen sivulla: samankaltaisia ohjeita (sama kategoria + sama
//   vaativuustaso; jos ei tarpeeksi, täydennetään pelkällä kategorialla)
// - Muilla sivuilla: uusimmat rakennusohjeet
class PP_Suositellut_Ohjeet_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'pp_suositellut_ohjeet',
            'Puupankki: Suositellut ohjeet',
            [ 'description' => 'Rakennusohjeen sivulla samankaltaisia ohjeita, muualla uusimmat ohjeet.' ]
        );
    }

    // Hallinnan lomake (Ulkoasu → Vimpaimet)
    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, [
            'otsikko_ohje' => 'Sinua voisi kiinnostaa myös',
            'otsikko_muu'  => 'Uusimmat rakennusohjeet',
            'maara'        => 3,
        ] );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'otsikko_ohje' ) ); ?>">Otsikko rakennusohjeen sivulla</label>
            <input type="text" class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'otsikko_ohje' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'otsikko_ohje' ) ); ?>"
                   value="<?php echo esc_attr( $instance['otsikko_ohje'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'otsikko_muu' ) ); ?>">Otsikko muilla sivuilla</label>
            <input type="text" class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'otsikko_muu' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'otsikko_muu' ) ); ?>"
                   value="<?php echo esc_attr( $instance['otsikko_muu'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'maara' ) ); ?>">Ohjeiden määrä</label>
            <input type="number" min="1" max="10" class="tiny-text"
                   id="<?php echo esc_attr( $this->get_field_id( 'maara' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'maara' ) ); ?>"
                   value="<?php echo esc_attr( $instance['maara'] ); ?>">
        </p>
        <?php
    }

    // Lomakkeen tallennus – kaikki kentät sanitoidaan
    public function update( $new_instance, $old_instance ) {
        return [
            'otsikko_ohje' => sanitize_text_field( $new_instance['otsikko_ohje'] ?? '' ),
            'otsikko_muu'  => sanitize_text_field( $new_instance['otsikko_muu'] ?? '' ),
            'maara'        => max( 1, min( 10, absint( $new_instance['maara'] ?? 3 ) ) ),
        ];
    }

    // Julkinen puoli
    public function widget( $args, $instance ) {
        $maara = max( 1, absint( $instance['maara'] ?? 3 ) );

        if ( is_singular( 'rakennusohje' ) ) {
            $otsikko = $instance['otsikko_ohje'] ?? '';
            $ohjeet  = $this->hae_samankaltaiset( get_queried_object_id(), $maara );
        } else {
            $otsikko = $instance['otsikko_muu'] ?? '';
            $ohjeet  = get_posts( [
                'post_type'      => 'rakennusohje',
                'post_status'    => 'publish',
                'posts_per_page' => $maara,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ] );
        }

        // Jos ei näytettävää, ei tulosteta vimpainta lainkaan
        if ( ! $ohjeet ) {
            return;
        }

        echo $args['before_widget'];
        if ( $otsikko !== '' ) {
            echo $args['before_title'] . esc_html( $otsikko ) . $args['after_title'];
        }
        echo '<div class="pp-suositellut">';
        foreach ( $ohjeet as $ohje ) {
            echo pp_ohje_kortti( $ohje->ID, false );
        }
        echo '</div>';
        echo $args['after_widget'];
    }

    // Samankaltaisten haku kahdessa vaiheessa
    private function hae_samankaltaiset( $nykyinen_id, $maara ) {
        $kategoriat = wp_get_post_terms( $nykyinen_id, 'ohjekategoria', [ 'fields' => 'ids' ] );
        $vaativuus  = get_post_meta( $nykyinen_id, '_pp_vaativuus', true );

        $perus = [
            'post_type'    => 'rakennusohje',
            'post_status'  => 'publish',
            'post__not_in' => [ $nykyinen_id ],
            'orderby'      => 'rand',
        ];
        if ( $kategoriat && ! is_wp_error( $kategoriat ) ) {
            $perus['tax_query'] = [
                [
                    'taxonomy' => 'ohjekategoria',
                    'field'    => 'term_id',
                    'terms'    => $kategoriat,
                ],
            ];
        }

        $tulokset = [];

        // Vaihe 1: sama kategoria JA sama vaativuustaso
        if ( $vaativuus ) {
            $tulokset = get_posts( array_merge( $perus, [
                'posts_per_page' => $maara,
                'meta_query'     => [
                    [ 'key' => '_pp_vaativuus', 'value' => $vaativuus ],
                ],
            ] ) );
        }

        // Vaihe 2: jos ei täyttä määrää, täydennetään pelkällä kategorialla
        if ( count( $tulokset ) < $maara ) {
            $loydetyt   = wp_list_pluck( $tulokset, 'ID' );
            $tulokset   = array_merge( $tulokset, get_posts( array_merge( $perus, [
                'posts_per_page' => $maara - count( $tulokset ),
                'post__not_in'   => array_merge( [ $nykyinen_id ], $loydetyt ),
            ] ) ) );
        }

        return $tulokset;
    }
}

function pp_rekisteroi_vimpain() {
    register_widget( 'PP_Suositellut_Ohjeet_Widget' );
}
add_action( 'widgets_init', 'pp_rekisteroi_vimpain' );
