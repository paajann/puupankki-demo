<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Vimpain: Suositellut ohjeet
// - Rakennusohjeen sivulla: samankaltaisia ohjeita (sama kategoria + sama
//   difficulty; if that yields too few, fall back to category alone)
// - Muilla sivuilla: uusimmat rakennusohjeet
class PP_Recommended_Guides_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'pp_suositellut_ohjeet',
            'Puupankki: Suositellut ohjeet',
            [ 'description' => 'Rakennusohjeen sivulla samankaltaisia ohjeita, muualla uusimmat ohjeet.' ]
        );
    }

    // Hallinnan lomake (Ulkoasu → Vimpaimet)
    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, [
            'otsikko_ohje' => 'Sinua voisi kiinnostaa myös',
            'otsikko_muu'  => 'Uusimmat rakennusohjeet',
            'maara'        => 3,
        ] );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'otsikko_ohje' ) ); ?>">Otsikko rakennusohjeen sivulla</label>
            <input type="text" class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'otsikko_ohje' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'otsikko_ohje' ) ); ?>"
                   value="<?php echo esc_attr( $instance['otsikko_ohje'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'otsikko_muu' ) ); ?>">Otsikko muilla sivuilla</label>
            <input type="text" class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'otsikko_muu' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'otsikko_muu' ) ); ?>"
                   value="<?php echo esc_attr( $instance['otsikko_muu'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'maara' ) ); ?>">Ohjeiden määrä</label>
            <input type="number" min="1" max="10" class="tiny-text"
                   id="<?php echo esc_attr( $this->get_field_id( 'maara' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'maara' ) ); ?>"
                   value="<?php echo esc_attr( $instance['maara'] ); ?>">
        </p>
        <?php
    }

    // Saving the form: every field is sanitised
    public function update( $new_instance, $old_instance ) {
        return [
            'otsikko_ohje' => sanitize_text_field( $new_instance['otsikko_ohje'] ?? '' ),
            'otsikko_muu'  => sanitize_text_field( $new_instance['otsikko_muu'] ?? '' ),
            'maara'        => max( 1, min( 10, absint( $new_instance['maara'] ?? 3 ) ) ),
        ];
    }

    // Julkinen puoli
    public function widget( $args, $instance ) {
        $count = max( 1, absint( $instance['maara'] ?? 3 ) );

        if ( is_singular( 'rakennusohje' ) ) {
            $title = $instance['otsikko_ohje'] ?? '';
            $guides  = $this->find_similar( get_queried_object_id(), $count );
        } else {
            $title = $instance['otsikko_muu'] ?? '';
            $guides  = get_posts( [
                'post_type'      => 'rakennusohje',
                'post_status'    => 'publish',
                'posts_per_page' => $count,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ] );
        }

        // Nothing to show means the widget is not printed at all
        if ( ! $guides ) {
            return;
        }

        echo $args['before_widget'];
        if ( $title !== '' ) {
            echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        }
        echo '<div class="pp-recommended">';
        foreach ( $guides as $guide ) {
            echo pp_guide_card( $guide->ID, false );
        }
        echo '</div>';
        echo $args['after_widget'];
    }

    // Samankaltaisten haku kahdessa vaiheessa
    private function find_similar( $current_id, $count ) {
        $categories = wp_get_post_terms( $current_id, 'ohjekategoria', [ 'fields' => 'ids' ] );
        $difficulty  = get_post_meta( $current_id, '_pp_vaativuus', true );

        $base_args = [
            'post_type'    => 'rakennusohje',
            'post_status'  => 'publish',
            'post__not_in' => [ $current_id ],
            'orderby'      => 'rand',
        ];
        if ( $categories && ! is_wp_error( $categories ) ) {
            $base_args['tax_query'] = [
                [
                    'taxonomy' => 'ohjekategoria',
                    'field'    => 'term_id',
                    'terms'    => $categories,
                ],
            ];
        }

        $results = [];

        // Step 1: same category AND same difficulty
        if ( $difficulty ) {
            $results = get_posts( array_merge( $base_args, [
                'posts_per_page' => $count,
                'meta_query'     => [
                    [ 'key' => '_pp_vaativuus', 'value' => $difficulty ],
                ],
            ] ) );
        }

        // Step 2: if that is not enough, top up with category alone
        if ( count( $results ) < $count ) {
            $found_ids   = wp_list_pluck( $results, 'ID' );
            $results   = array_merge( $results, get_posts( array_merge( $base_args, [
                'posts_per_page' => $count - count( $results ),
                'post__not_in'   => array_merge( [ $current_id ], $found_ids ),
            ] ) ) );
        }

        return $results;
    }
}

function pp_register_widget() {
    register_widget( 'PP_Recommended_Guides_Widget' );
}
add_action( 'widgets_init', 'pp_register_widget' );
