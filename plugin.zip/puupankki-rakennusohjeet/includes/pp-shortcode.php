<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Shortcode: [ohjekauppa] or [ohjekauppa kategoria="pihakalusteet"]
function pp_guide_shop_shortcode( $atts ) {
    $atts = shortcode_atts( [
        'kategoria' => '',
    ], $atts );

    $args = [
        'post_type'      => 'rakennusohje',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    // If a category was given, narrow the query to it
    if ( $atts['kategoria'] !== '' ) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'ohjekategoria',
                'field'    => 'slug',
                'terms'    => sanitize_title( $atts['kategoria'] ),
            ],
        ];
    }

    $search = new WP_Query( $args );

    $html = '<div class="pp-guide-shop">';
    if ( $search->have_posts() ) {
        while ( $search->have_posts() ) {
            $search->the_post();
            $html .= pp_guide_card( get_the_ID(), true );
        }
    } else {
        $html .= '<p>Rakennusohjeita ei löytynyt.</p>';
    }
    $html .= '</div>';

    // Palautetaan WordPressin oma kysely ennalleen, ettei lyhytkoodin haku
    // does not disturb the rest of the page
    wp_reset_postdata();

    return $html;
}
add_shortcode( 'ohjekauppa', 'pp_guide_shop_shortcode' );
