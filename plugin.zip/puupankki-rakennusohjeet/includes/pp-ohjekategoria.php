<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Oma taksonomia: Ohjekategoria (esim. Pihakalusteet, Huonekalut)
function pp_ohjekategoria_taxonomy() {
    register_taxonomy( 'ohjekategoria', 'rakennusohje', [
        'labels' => [
            'name'          => 'Ohjekategoriat',
            'singular_name' => 'Ohjekategoria',
            'search_items'  => 'Etsi ohjekategorioita',
            'all_items'     => 'Kaikki ohjekategoriat',
            'edit_item'     => 'Muokkaa ohjekategoriaa',
            'update_item'   => 'Päivitä ohjekategoria',
            'add_new_item'  => 'Lisää ohjekategoria',
            'new_item_name' => 'Uuden ohjekategorian nimi',
            'menu_name'     => 'Ohjekategoriat',
        ],
        'hierarchical'      => true,
        'rewrite'           => [ 'slug' => 'ohjekategoria' ],
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ] );
}
add_action( 'init', 'pp_ohjekategoria_taxonomy' );
