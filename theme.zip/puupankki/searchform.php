<form role="search" method="get" class="header-search__form" action="<?php echo esc_url(home_url('/')); ?>">
    <label for="haku-kentta" class="screen-reader-text">Hae sivustolta</label>
    <input type="search" id="haku-kentta" name="s"
           value="<?php echo esc_attr(get_search_query()); ?>"
           placeholder="Hae puulajeja, artikkeleita ja projekteja"
           autocomplete="off">
</form>