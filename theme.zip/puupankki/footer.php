<?php
$is_home     = is_front_page();
$is_species = is_post_type_archive('puulaji') || is_singular('puulaji');
$is_calculators = is_page('laskurit');
// On mobile the other sections sit behind the Menu button, so highlight Menu
$in_menu = !$is_home && !$is_species && !$is_calculators;
?>

<footer id="site-footer">
    <div class="footer-inner">
        <a class="footer-logo" href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo get_template_directory_uri(); ?>/images/logo-vihrea.svg" alt="<?php bloginfo('name'); ?>, etusivulle">
        </a>

        <?php for ($i = 1; $i <= 3; $i++) :
            if (is_active_sidebar('footer-' . $i)) : ?>
                <div class="footer-col footer-col--<?php echo $i; ?>">
                    <?php dynamic_sidebar('footer-' . $i); ?>
                </div>
            <?php endif;
        endfor; ?>
    </div>

    <p class="footer-copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
</footer>

<nav class="bottom-nav" aria-label="Pikavalikko">
    <ul>
        <li>
            <a href="<?php echo esc_url(home_url('/')); ?>" <?php if ($is_home) echo 'class="is-active" aria-current="page"'; ?>>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
                <span>Koti</span>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url(get_post_type_archive_link('puulaji')); ?>" <?php if ($is_species) echo 'class="is-active" aria-current="page"'; ?>>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L12 3l4 4.3a1 1 0 0 1-.8 1.7H15l3 3.3a1 1 0 0 1-.7 1.7H17Z"/><path d="M12 22v-3"/></svg>
                <span>Puulajit</span>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url(home_url('/laskurit/')); ?>" <?php if ($is_calculators) echo 'class="is-active" aria-current="page"'; ?>>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="16" height="20" x="4" y="2" rx="2"/><path d="M8 6h8"/><path d="M16 14v4"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/></svg>
                <span>Laskurit</span>
            </a>
        </li>
        <li>
            <button class="menu-toggle<?php if ($in_menu) echo ' is-active'; ?>" aria-expanded="false" aria-controls="main-nav">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/></svg>
                <span>Menu</span>
            </button>
        </li>
    </ul>
</nav>

<?php wp_footer(); ?>
</body>
</html>