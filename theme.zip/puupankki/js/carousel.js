document.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('.card-list--scroll, .gallery').forEach(initCarousel);

    function initCarousel(track) {
        const controls = track.nextElementSibling;
        if (!controls || !controls.classList.contains('carousel-controls')) return;

        const prev = controls.querySelector('.carousel-prev');
        const next = controls.querySelector('.carousel-next');
        const dotsWrap = controls.querySelector('.carousel-dots');
        const items = track.children;

        // No carousel is needed with fewer than two items
        if (items.length < 2) {
            controls.hidden = true;
            return;
        }

        // Yksi piste jokaista kohdetta kohden
        for (let i = 0; i < items.length; i++) {
            const dot = document.createElement('span');
            dot.className = 'carousel-dot';
            dotsWrap.appendChild(dot);
        }
        const dots = dotsWrap.querySelectorAll('.carousel-dot');

        // One step equals the item width plus the gap
        function step() {
            return items[1].offsetLeft - items[0].offsetLeft;
        }

        function currentIndex() {
            return Math.round(track.scrollLeft / step());
        }

        function goTo(index) {
            track.scrollTo({ left: index * step(), behavior: 'smooth' });
        }

        function update() {
            const i = currentIndex();
            dots.forEach(function (dot, n) {
                dot.classList.toggle('is-active', n === i);
            });
            prev.disabled = i === 0;
            next.disabled = i >= items.length - 1;
        }

        prev.addEventListener('click', function () {
            goTo(Math.max(currentIndex() - 1, 0));
        });
        next.addEventListener('click', function () {
            goTo(Math.min(currentIndex() + 1, items.length - 1));
        });
        track.addEventListener('scroll', update);

        update();
    }
});