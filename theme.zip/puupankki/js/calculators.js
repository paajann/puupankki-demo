/* Puupankki calculators – all arithmetic runs in the browser.
   Species data and factors come from PHP (puupankkiCalculator).

   The calculators share one set of inputs: area, board size and waste give the
   volume, which the price and the carbon footprint are both built on. That is
   why the input panels are grouped by what they ask for rather than one panel
   per calculator.

   Visible labels stay in Finnish; identifiers are in English. */
(function () {
    'use strict';

    var root = document.getElementById('puupankki-calculators');
    if (!root || typeof puupankkiCalculator === 'undefined') {
        return;
    }

    var species = puupankkiCalculator.species;
    var factors = puupankkiCalculator.factors;

    /* The front page links here as /laskurit/?laskuri=hinta. The query value
       is Finnish to match the site's other URLs; this map turns it into the
       internal calculator key. */
    var QUERY_TO_KEY = {
        tarve: 'quantity',
        menekki: 'quantity',
        hinta: 'price',
        co2: 'co2',
        kemikaalit: 'chemical'
    };

    var state = {
        calculators: { quantity: true, price: false, co2: false, chemical: false },
        materials: [],            // species ids, in the order they were picked
        waste: factors.waste,     // per cent
        wastePreset: '',          // key in factors.waste_presets, empty = typed by hand
        inputs: {}                // id -> see defaultInput()
    };

    var panelsEl     = document.getElementById('calc-panels');
    var emptyEl      = document.getElementById('calc-empty');
    var resultsBody  = document.getElementById('calc-results-body');
    var resultsEmpty = document.getElementById('calc-results-empty');

    /* ---------------- Small helpers ---------------- */

    function findSpecies(id) {
        for (var i = 0; i < species.length; i++) {
            if (species[i].id === id) { return species[i]; }
        }
        return null;
    }

    function num(value) {
        return parseFloat(String(value).replace(',', '.'));
    }

    function defaultInput() {
        return {
            areaMode: 'm2',   // m2 = one field, m = metres × metres, cm = cm × cm
            area: '',         // used when areaMode is m2
            side1: '',        // length, used when areaMode is m or cm
            side2: '',        // width
            thickness: factors.thicknesses[1],
            width: factors.widths[1],
            type: 'raakapuu',
            finish: 'ei',
            transport: 'mid'
        };
    }

    /* The visitor rarely has a square-metre figure ready, so the area can also
       be given as the two sides of the surface. */
    function areaOf(input) {
        if (input.areaMode === 'm2') {
            var direct = num(input.area);
            return direct > 0 ? direct : 0;
        }
        var a = num(input.side1), b = num(input.side2);
        if (!(a > 0) || !(b > 0)) { return 0; }
        return input.areaMode === 'cm' ? (a * b) / 10000 : a * b;
    }

    function fmt(number, decimals) {
        return new Intl.NumberFormat('fi-FI', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(number);
    }

    function esc(text) {
        return String(text).replace(/[&<>"']/g, function (m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
        });
    }

    function wastePercent() {
        return Math.max(0, num(state.waste) || 0);
    }

    /* ---------------- Selection buttons ---------------- */

    var calculatorButtons = root.querySelectorAll('[data-calculator]');

    function syncCalculatorButtons() {
        calculatorButtons.forEach(function (button) {
            var key = button.getAttribute('data-calculator');
            var on  = !!state.calculators[key];
            button.classList.toggle('is-active', on);
            button.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
    }

    calculatorButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var key = button.getAttribute('data-calculator');
            state.calculators[key] = !state.calculators[key];
            syncCalculatorButtons();
            renderPanels();
            calculate();
        });
    });

    root.querySelectorAll('[data-material]').forEach(function (button) {
        button.addEventListener('click', function () {
            var id = button.getAttribute('data-material');
            var index = state.materials.indexOf(id);
            if (index === -1) {
                state.materials.push(id);
                if (!state.inputs[id]) { state.inputs[id] = defaultInput(); }
            } else {
                state.materials.splice(index, 1);
            }
            var isSelected = index === -1;
            button.classList.toggle('is-active', isSelected);
            button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
            renderPanels();
            calculate();
        });
    });

    /* ---------------- Panels (the input fields) ---------------- */

    function chipGroup(label, field, options, selected) {
        var html = '<div class="calc__chips" role="group" aria-label="' + esc(label) + '">';
        Object.keys(options).forEach(function (key) {
            var active = key === selected ? ' is-active' : '';
            html += '<button type="button" class="calc__chip' + active + '" data-field="' + esc(field) + '" data-value="' + esc(key) + '" aria-pressed="' + (key === selected) + '">' + esc(options[key].label) + '</button>';
        });
        return html + '</div>';
    }

    function selectField(label, attr, id, options, selected) {
        var html = '<label class="calc__select"><span>' + esc(label) + '</span><select ' + attr + '="' + esc(id) + '">';
        options.forEach(function (option) {
            html += '<option value="' + esc(option.value) + '"' + (String(option.value) === String(selected) ? ' selected' : '') + '>' + esc(option.label) + '</option>';
        });
        return html + '</select></label>';
    }

    var CHOOSE_MATERIAL = '<p class="calc__hint calc__hint--panel">Valitse materiaali yllä, niin kentät tulevat näkyviin.</p>';

    /* The area row: either one square-metre field or two sides, plus the unit
       picker that switches between them. */
    function areaRow(id, item, input) {
        var units = [
            { value: 'm2', label: 'm²' },
            { value: 'm',  label: 'm × m' },
            { value: 'cm', label: 'cm × cm' }
        ];
        var html = '<div class="calc__row calc__row--stacked"><span class="calc__label">' + esc(item.label) + ' – pinta-ala</span><div class="calc__choices-row">';

        if (input.areaMode === 'm2') {
            html += '<span class="calc__field"><label class="screen-reader-text" for="area-' + esc(id) + '">' + esc(item.label) + ' pinta-ala neliömetreinä</label>'
                  + '<input type="number" id="area-' + esc(id) + '" inputmode="decimal" min="0" step="0.1" placeholder="0" value="' + esc(input.area) + '" data-area="' + esc(id) + '"></span>';
        } else {
            var unit = input.areaMode === 'cm' ? 'senttimetreinä' : 'metreinä';
            html += '<span class="calc__field"><label class="screen-reader-text" for="side1-' + esc(id) + '">' + esc(item.label) + ' pituus ' + esc(unit) + '</label>'
                  + '<input type="number" id="side1-' + esc(id) + '" inputmode="decimal" min="0" step="0.1" placeholder="pituus" value="' + esc(input.side1) + '" data-side1="' + esc(id) + '"></span>'
                  + '<span class="calc__times" aria-hidden="true">×</span>'
                  + '<span class="calc__field"><label class="screen-reader-text" for="side2-' + esc(id) + '">' + esc(item.label) + ' leveys ' + esc(unit) + '</label>'
                  + '<input type="number" id="side2-' + esc(id) + '" inputmode="decimal" min="0" step="0.1" placeholder="leveys" value="' + esc(input.side2) + '" data-side2="' + esc(id) + '"></span>';
        }

        html += selectField('Yksikkö', 'data-area-mode', id, units, input.areaMode);
        html += '</div>';

        /* Always in the markup so typing can update it without a redraw; it is
           only filled when the sides are given in something other than m². */
        html += '<p class="calc__hint calc__hint--panel" data-area-sum="' + esc(id) + '">' + esc(areaSumText(id)) + '</p>';
        return html + '</div>';
    }

    function areaSumText(id) {
        var input = state.inputs[id];
        if (!input || input.areaMode === 'm2') { return ''; }
        var area = areaOf(input);
        return area > 0 ? '= ' + fmt(area, 2) + ' m²' : '';
    }

    function syncAreaSum(id) {
        var el = panelsEl.querySelector('[data-area-sum="' + id + '"]');
        if (el) { el.textContent = areaSumText(id); }
    }

    function renderPanels() {
        var hasMaterials = state.materials.length > 0;
        var needsTreatment = state.calculators.price || state.calculators.co2 || state.calculators.chemical;
        emptyEl.hidden = true;

        var html = '';

        /* 1. Amount: area, board size and waste. Everything else is built on
              the volume these give, so this panel is always shown. */
        html += '<section class="calc__panel calc__panel--quantity"><h3 class="calc__panel-heading">Materiaalin määrä</h3>';
        if (!hasMaterials) {
            html += CHOOSE_MATERIAL;
        } else {
            state.materials.forEach(function (id) {
                var item = findSpecies(id), input = state.inputs[id];
                html += areaRow(id, item, input);
                html += '<div class="calc__row calc__row--stacked"><span class="calc__label">' + esc(item.label) + ' – lautakoko</span><div class="calc__choices-row">';
                html += selectField('Paksuus', 'data-thickness', id, factors.thicknesses.map(function (t) {
                    return { value: t, label: t + ' mm' };
                }), input.thickness);
                html += selectField('Leveys', 'data-width', id, factors.widths.map(function (w) {
                    return { value: w, label: w + ' mm' };
                }), input.width);
                html += '</div></div>';
            });

            var presetOptions = [{ value: '', label: 'Syötän itse' }];
            Object.keys(factors.waste_presets).forEach(function (key) {
                var preset = factors.waste_presets[key];
                presetOptions.push({ value: key, label: preset.label + ' ' + preset.waste + ' %' });
            });
            html += '<div class="calc__row calc__row--stacked"><span class="calc__label">Hukkavara käyttötarkoituksen mukaan</span><div class="calc__choices-row">'
                  + selectField('Käyttötarkoitus', 'data-waste-preset', 'all', presetOptions, state.wastePreset)
                  + '<span class="calc__field"><label class="screen-reader-text" for="calc-waste">Hukkavara prosentteina</label>'
                  + '<input type="number" id="calc-waste" inputmode="numeric" min="0" max="60" step="1" value="' + esc(state.waste) + '" data-waste><span class="calc__unit">%</span></span>'
                  + '</div><p class="calc__hint calc__hint--panel">Hukkavara on se osuus, joka menee katkoihin ja sovitukseen.</p></div>';
        }
        html += '</section>';

        /* 2. Treatment: needed by the price, the footprint and the chemical
              load alike, so it is one panel rather than three. */
        if (needsTreatment) {
            html += '<section class="calc__panel calc__panel--price"><h3 class="calc__panel-heading">Puun tyyppi ja pintakäsittely</h3>';
            if (!hasMaterials) { html += CHOOSE_MATERIAL; }
            state.materials.forEach(function (id) {
                var item = findSpecies(id), input = state.inputs[id];
                html += '<div class="calc__row calc__row--stacked"><span class="calc__label">' + esc(item.label) + ' – puun tyyppi</span>'
                      + chipGroup(item.label + ' puun tyyppi', 'type:' + id, factors.types, input.type) + '</div>';
                html += '<div class="calc__row calc__row--stacked"><span class="calc__label">' + esc(item.label) + ' – pintakäsittely</span>'
                      + chipGroup(item.label + ' pintakäsittely', 'finish:' + id, factors.finishes, input.finish) + '</div>';
            });
            html += '</section>';
        }

        /* 3. Transport only matters for the footprint. */
        if (state.calculators.co2) {
            html += '<section class="calc__panel calc__panel--co2"><h3 class="calc__panel-heading">Kuljetus</h3><p class="calc__hint calc__hint--panel">Matka, jonka puu kulkee sinulle asti.</p>';
            if (!hasMaterials) { html += CHOOSE_MATERIAL; }
            state.materials.forEach(function (id) {
                var item = findSpecies(id), input = state.inputs[id];
                html += '<div class="calc__row calc__row--stacked"><span class="calc__label">' + esc(item.label) + ' – kuljetusmatka</span>'
                      + chipGroup(item.label + ' kuljetusmatka', 'transport:' + id, factors.transport, input.transport) + '</div>';
            });
            html += '</section>';
        }

        panelsEl.innerHTML = html;
    }

    /* Field changes update the state and recalculate. The panels are only
       redrawn when the shape of the fields changes, so typing never loses
       focus. */
    panelsEl.addEventListener('input', function (e) {
        var el = e.target;
        if (el.hasAttribute('data-area'))  { state.inputs[el.getAttribute('data-area')].area = el.value; }
        if (el.hasAttribute('data-side1')) {
            state.inputs[el.getAttribute('data-side1')].side1 = el.value;
            syncAreaSum(el.getAttribute('data-side1'));
        }
        if (el.hasAttribute('data-side2')) {
            state.inputs[el.getAttribute('data-side2')].side2 = el.value;
            syncAreaSum(el.getAttribute('data-side2'));
        }
        if (el.hasAttribute('data-waste')) {
            state.waste = el.value;
            // A hand-typed percentage no longer matches a named use case
            state.wastePreset = '';
            var preset = panelsEl.querySelector('[data-waste-preset]');
            if (preset) { preset.value = ''; }
        }
        calculate();
    });

    panelsEl.addEventListener('change', function (e) {
        var el = e.target, changed = false;
        if (el.hasAttribute('data-thickness')) {
            state.inputs[el.getAttribute('data-thickness')].thickness = el.value;
            changed = true;
        }
        if (el.hasAttribute('data-width')) {
            state.inputs[el.getAttribute('data-width')].width = el.value;
            changed = true;
        }
        if (el.hasAttribute('data-waste-preset')) {
            state.wastePreset = el.value;
            if (el.value && factors.waste_presets[el.value]) {
                state.waste = factors.waste_presets[el.value].waste;
                var field = panelsEl.querySelector('[data-waste]');
                if (field) { field.value = state.waste; }
            }
            changed = true;
        }
        if (el.hasAttribute('data-area-mode')) {
            // The fields themselves change, so this one does need a redraw
            state.inputs[el.getAttribute('data-area-mode')].areaMode = el.value;
            renderPanels();
            changed = true;
        }
        /* Only recalculate for the fields this handler owns. A number field
           also fires 'change' when it loses focus, and redrawing the results
           then would destroy the info button the visitor is moving focus to. */
        if (changed) { calculate(); }
    });

    panelsEl.addEventListener('click', function (e) {
        var chip = e.target.closest('.calc__chip');
        if (!chip) { return; }
        var parts = chip.getAttribute('data-field').split(':');
        state.inputs[parts[1]][parts[0]] = chip.getAttribute('data-value');
        chip.parentNode.querySelectorAll('.calc__chip').forEach(function (c) {
            var active = c === chip;
            c.classList.toggle('is-active', active);
            c.setAttribute('aria-pressed', active ? 'true' : 'false');
        });
        calculate();
    });

    /* ---------------- Calculation ---------------- */

    function calculate() {
        var rows = [];
        var waste = wastePercent() / 100;

        state.materials.forEach(function (id) {
            var item = findSpecies(id), input = state.inputs[id];
            var area = areaOf(input);
            if (!(area > 0)) { return; }

            var type      = factors.types[input.type];
            var finish    = factors.finishes[input.finish];
            var transport = factors.transport[input.transport];

            // Amount: the surface plus its waste, times the board thickness
            var areaWithWaste = area * (1 + waste);
            var volume = areaWithWaste * (Number(input.thickness) / 1000);
            var metres = areaWithWaste / (Number(input.width) / 1000);

            // Price: timber by the cubic metre, finish by the square metre of
            // surface actually covered (offcuts are not painted)
            var pricePerM3  = item.price * type.price;
            var priceTimber = volume * pricePerM3;
            var priceFinish = area * finish.price;

            // Footprint: the timber itself, the lorry, and the finish
            var co2Timber    = volume * item.co2 * type.co2;
            var co2Transport = (volume * factors.timber_density / 1000) * transport.km * factors.freight_kg_per_tkm;
            var co2Finish    = area * finish.co2;

            rows.push({
                item: item, input: input,
                area: area, areaWithWaste: areaWithWaste, volume: volume, metres: metres,
                type: type, finish: finish, transport: transport,
                pricePerM3: pricePerM3,
                priceTimber: priceTimber, priceFinish: priceFinish,
                price: priceTimber + priceFinish,
                co2Timber: co2Timber, co2Transport: co2Transport, co2Finish: co2Finish,
                co2: co2Timber + co2Transport + co2Finish,
                chemicalScore: type.chemical + finish.chemical
            });
        });

        renderResults(rows);
    }

    /* ---------------- Reading the numbers ---------------- */

    /* Where a value sits across every material in the calculator, as one of
       three bands: 1 = low third, 2 = middle, 3 = top third. */
    function band(value, key) {
        var min = null, max = null;
        species.forEach(function (s) {
            if (min === null || s[key] < min) { min = s[key]; }
            if (max === null || s[key] > max) { max = s[key]; }
        });
        if (min === null || max === min) { return null; }
        var ratio = Math.min(1, Math.max(0, (value - min) / (max - min)));
        return ratio < 0.34 ? 1 : (ratio < 0.67 ? 2 : 3);
    }

    function average(key) {
        if (!species.length) { return 0; }
        var sum = 0;
        species.forEach(function (s) { sum += s[key]; });
        return sum / species.length;
    }

    /* Price level as euro signs rather than a slider. It is shown per material,
       because the question it answers is whether the material you picked is a
       cheap or an expensive one – not what the mix averages out to. */
    var PRICE_WORDS = { 1: 'edullisimpien joukossa', 2: 'keskihintainen', 3: 'kalleimpien joukossa' };

    function euroSigns(level) {
        var signs = '';
        for (var i = 1; i <= 3; i++) {
            signs += '<span class="calc__euro' + (i <= level ? ' is-on' : '') + '">€</span>';
        }
        return signs;
    }

    function priceLevels(rows, unit) {
        var html = '';
        rows.forEach(function (r) {
            var level = band(r.item.price, 'price');
            if (!level) { return; }
            html += '<p class="calc__level"><span class="calc__euros" aria-hidden="true">' + euroSigns(level) + '</span>'
                  + '<span><strong>' + esc(r.item.label) + '</strong> on ' + esc(PRICE_WORDS[level])
                  + ', ' + esc(fmt(r.item.price, 0)) + ' ' + esc(unit) + ' raakapuuna.</span></p>';
        });
        if (!html) { return ''; }
        return html + '<p class="calc__note">Keskihinta kaikista laskurin materiaaleista on '
             + esc(fmt(average('price'), 0)) + ' ' + esc(unit) + '.</p>';
    }

    /* The same three bands for emissions, but written out: the car comparison
       above already carries the magnitude, so no second graphic is needed. */
    function co2Level(value, unit) {
        var level = band(value, 'co2');
        if (!level) { return ''; }
        var words = {
            1: 'vähäpäästöisimpien joukossa',
            2: 'keskitasoa',
            3: 'päästöiltään suurimpien joukossa'
        };
        return '<p class="calc__note">Valintasi on ' + esc(words[level])
             + '. Keskiarvo kaikista materiaaleista on ' + esc(fmt(average('co2'), 2)) + ' ' + esc(unit) + '.</p>';
    }

    /* Chemical load is reported as a level, not a quantity: there is no
       reliable source for how much preservative or paint a given product
       leaves in the wood. */
    function chemicalLevel(score) {
        var levels = factors.chemical_levels;
        for (var i = 0; i < levels.length; i++) {
            if (score <= levels[i].max) { return levels[i]; }
        }
        return levels[levels.length - 1];
    }

    function breakdown(key, content, summary) {
        return '<details class="calc__breakdown" data-details="' + esc(key) + '"><summary>'
             + esc(summary || 'Näytä erittely') + '</summary>' + content + '</details>';
    }

    /* The info icon sits beside the heading, never inside it: a button inside a
       heading becomes part of the heading text for screen readers. The tooltip
       shows on hover and on keyboard focus, and Esc closes it. */
    function info(key, text) {
        var id = 'calc-tip-' + key;
        return '<span class="calc__info">'
             + '<button type="button" class="calc__info-button" aria-describedby="' + esc(id) + '">'
             + 'i<span class="screen-reader-text">Mistä luku tulee</span></button>'
             + '<span class="calc__tooltip" role="tooltip" id="' + esc(id) + '">' + esc(text) + '</span>'
             + '</span>';
    }

    function heading(title, key, text) {
        return '<div class="calc__result-head"><h3 class="calc__result-heading">' + esc(title) + '</h3>'
             + info(key, text) + '</div>';
    }

    /* Where each number came from, as recorded against the species in
       WordPress. Appended to the tooltip so the explanation of the method is
       followed by the provenance of the figures it used. A species with no
       source recorded is named as such rather than quietly left out. */
    function sources(rows, field) {
        var known = [], missing = [];
        rows.forEach(function (r) {
            var source = r.item[field];
            if (source) {
                known.push(r.item.label + ': ' + source + (r.item.checked ? ' (' + r.item.checked + ')' : ''));
            } else {
                missing.push(r.item.label);
            }
        });
        var text = '';
        if (known.length)   { text += ' Lähteet – ' + known.join('; ') + '.'; }
        if (missing.length) { text += ' Lähdettä ei ole kirjattu: ' + missing.join(', ') + '.'; }
        return text;
    }

    /* Esc closes an open tooltip (WCAG 1.4.13 Dismissible). Dropping focus is
       not enough on its own, because the pointer may still be on the icon, so
       the tooltip is also held shut by a class until the pointer leaves. */
    root.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') { return; }
        var open = root.querySelector('.calc__info:hover, .calc__info:focus-within');
        if (!open) { return; }
        open.classList.add('is-dismissed');
        var button = open.querySelector('.calc__info-button');
        if (button) { button.blur(); }
    });

    /* Re-arm the tooltip once the pointer has actually left the icon, so a
       second hover shows it again. */
    root.addEventListener('mouseout', function (e) {
        var info = e.target.closest && e.target.closest('.calc__info');
        if (!info || !info.classList.contains('is-dismissed')) { return; }
        if (!info.contains(e.relatedTarget)) { info.classList.remove('is-dismissed'); }
    });

    /* ---------------- Results ---------------- */

    /* The results are redrawn on every keystroke, which throws away the DOM the
       visitor was using. These two remember what was open so that typing a new
       number does not close an expanded breakdown or a tooltip being read. */
    function openDetails() {
        var keys = [];
        resultsBody.querySelectorAll('details[open][data-details]').forEach(function (d) {
            keys.push(d.getAttribute('data-details'));
        });
        return keys;
    }

    function restoreResultsState(keys, tipId) {
        keys.forEach(function (key) {
            var el = resultsBody.querySelector('details[data-details="' + key + '"]');
            if (el) { el.open = true; }
        });
        if (tipId) {
            var button = resultsBody.querySelector('[aria-describedby="' + tipId + '"]');
            if (button) { button.focus(); }
        }
    }

    function renderResults(rows) {
        var wasOpen = openDetails();
        var focusedTip = (document.activeElement && resultsBody.contains(document.activeElement))
            ? document.activeElement.getAttribute('aria-describedby')
            : null;

        if (!rows.length) {
            resultsBody.innerHTML = '';
            resultsEmpty.hidden = false;
            return;
        }
        resultsEmpty.hidden = true;

        var html = '';
        var volumeTotal = 0;
        rows.forEach(function (r) { volumeTotal += r.volume; });

        // Material quantity
        if (state.calculators.quantity) {
            var metresTotal = 0, quantityRows = '';
            rows.forEach(function (r) {
                metresTotal += r.metres;
                quantityRows += '<div class="calc__result-row"><span class="calc__result-name">' + esc(r.item.label) + '</span>'
                              + '<span class="calc__result-value"><strong>' + esc(fmt(r.volume, 2)) + ' m³</strong>'
                              + '<small>' + esc(fmt(r.area, 1)) + ' m² · ' + esc(r.input.thickness) + ' × ' + esc(r.input.width) + ' mm · noin ' + esc(fmt(r.metres, 0)) + ' m lautaa</small></span></div>';
            });
            html += '<section class="calc__result">'
                  + heading('Materiaalimenekki', 'quantity', 'Pinta-ala kertaa laudan paksuus, hukkavara mukana. Tulos on kuutiometreinä, jossa sahatavaraa yleensä myydään.')
                  + '<p class="calc__headline"><strong>' + esc(fmt(volumeTotal, 2)) + ' m³</strong>'
                  + '<span>noin ' + esc(fmt(metresTotal, 0)) + ' metriä lautaa, hukkavara ' + esc(fmt(wastePercent(), 0)) + ' % mukana</span></p>'
                  + breakdown('quantity', quantityRows)
                  + '</section>';
        }

        // Price estimate
        if (state.calculators.price) {
            var priceTotal = 0, priceRows = '';
            rows.forEach(function (r) {
                priceTotal += r.price;
                priceRows += '<div class="calc__result-row"><span class="calc__result-name">' + esc(r.item.label) + '</span>'
                           + '<span class="calc__result-value"><strong>' + esc(fmt(r.price, 0)) + ' €</strong>'
                           + '<small>' + esc(fmt(r.pricePerM3, 0)) + ' €/m³ · ' + esc(r.type.label.toLowerCase())
                           + (r.priceFinish > 0 ? ' + ' + esc(r.finish.label.toLowerCase()) + ' ' + esc(fmt(r.priceFinish, 0)) + ' €' : '')
                           + '</small></span></div>';
            });
            html += '<section class="calc__result">'
                  + heading('Hinta-arvio', 'price', 'Kuutiomäärä kertaa puulajin viitehinta ja puun tyypin kerroin, plus pintakäsittely neliömetreittäin. Viitehinnat syötetään WordPressissä puulajikohtaisesti – ne ovat arvioita, eivät päivän hintoja.' + sources(rows, 'priceSource'))
                  + '<p class="calc__headline"><strong>' + esc(fmt(priceTotal, 0)) + ' €</strong>'
                  + '<span>noin ' + esc(fmt(priceTotal / volumeTotal, 0)) + ' € / m³</span></p>'
                  + priceLevels(rows, '€/m³')
                  + breakdown('price', priceRows)
                  + '</section>';
        }

        // Carbon footprint
        if (state.calculators.co2) {
            var co2Total = 0, co2Rows = '';
            rows.forEach(function (r) {
                co2Total += r.co2;
                co2Rows += '<div class="calc__result-row"><span class="calc__result-name">' + esc(r.item.label) + '</span>'
                         + '<span class="calc__result-value"><strong>' + esc(fmt(r.co2, 0)) + ' kg</strong>'
                         + '<small>puu ' + esc(fmt(r.co2Timber, 0)) + ' · kuljetus ' + esc(fmt(r.co2Transport, 1))
                         + (r.co2Finish > 0 ? ' · pintakäsittely ' + esc(fmt(r.co2Finish, 1)) : '') + '</small></span></div>';
            });
            var carKm        = co2Total / (factors.car_g_per_km / 1000);
            var carbonStored = volumeTotal * factors.carbon_storage;

            html += '<section class="calc__result">'
                  + heading('Hiilijalanjälki', 'co2', 'Kuutiomäärä kertaa puulajin päästökerroin, plus kuljetus (' + fmt(factors.timber_density, 0) + ' kg/m³ ja ' + fmt(factors.freight_kg_per_tkm, 1) + ' kg CO2e per tonnikilometri) ja pintakäsittely. Autovertailussa henkilöauto päästää ' + fmt(factors.car_g_per_km, 0) + ' g CO2e kilometrillä.' + sources(rows, 'co2Source'))
                  + '<p class="calc__headline"><strong>' + esc(fmt(co2Total, 0)) + ' kg CO₂e</strong>'
                  + '<span>vastaa noin ' + esc(fmt(carKm, 0)) + ' km ajoa henkilöautolla</span></p>'
                  + co2Level(co2Total / volumeTotal, 'kg CO₂e/m³')
                  + '<p class="calc__note calc__note--positive">Puu myös varastoi hiiltä: tämä määrä sitoo noin ' + esc(fmt(carbonStored, 0)) + ' kg CO₂ niin kauan kuin se on käytössä.</p>';

            /* The suggestion replaces the heaviest material in the mix, so it
               has to say which one – otherwise it looks like it is ignoring a
               lighter choice the visitor already made. */
            var heaviest = rows[0];
            rows.forEach(function (r) { if (r.item.co2 > heaviest.item.co2) { heaviest = r; } });

            var lighter = null;
            species.forEach(function (s) {
                if (state.materials.indexOf(s.id) !== -1) { return; }
                if (s.co2 < heaviest.item.co2 && (!lighter || s.co2 < lighter.co2)) { lighter = s; }
            });
            if (lighter) {
                /* Nominative throughout: Finnish case endings cannot be formed
                   in code (tammi → tammen, mänty → männyn), so the sentence is
                   built to avoid them. */
                html += '<p class="calc__tip">Eniten päästöjä: ' + esc(heaviest.item.label) + ', '
                      + esc(fmt(heaviest.item.co2, 0)) + ' kg CO₂e / m³. Vähäpäästöisempi vaihtoehto: '
                      + '<a href="' + esc(lighter.url) + '">' + esc(lighter.label) + '</a>, '
                      + esc(fmt(lighter.co2, 0)) + ' kg CO₂e / m³ raakapuuna.</p>';
            } else {
                html += '<p class="calc__tip">Valitsit jo vähäpäästöisimmät puulajit, joita laskurista löytyy.</p>';
            }
            html += breakdown('co2', co2Rows) + '</section>';
        }

        // Chemical load
        if (state.calculators.chemical) {
            var worst = rows[0];
            rows.forEach(function (r) { if (r.chemicalScore > worst.chemicalScore) { worst = r; } });
            var level = chemicalLevel(worst.chemicalScore);

            html += '<section class="calc__result">'
                  + heading('Kemikaalikuorma', 'chemical', 'Arvio on kolmiportainen, ei määrä: puun tyyppi ja pintakäsittely kertovat, kuinka paljon kemikaaleja valinta tuo mukanaan. Tarkat pitoisuudet löytyvät tuotteen käyttöturvatiedotteesta.')
                  + '<p class="calc__headline"><strong>' + esc(level.label) + '</strong><span>' + esc(level.summary) + '</span></p>'
                  + '<p class="calc__note">' + esc(level.advice) + '</p>';

            if (rows.length > 1) {
                var chemicalRows = '';
                rows.forEach(function (r) {
                    chemicalRows += '<div class="calc__result-row"><span class="calc__result-name">' + esc(r.item.label) + '</span>'
                                  + '<span class="calc__result-value"><strong>' + esc(chemicalLevel(r.chemicalScore).label) + '</strong>'
                                  + '<small>' + esc(r.type.label.toLowerCase()) + ' · ' + esc(r.finish.label.toLowerCase()) + '</small></span></div>';
                });
                html += breakdown('chemical', chemicalRows);
            }
            html += '</section>';
        }

        // The values that were entered, so nobody has to remember them
        var entered = '<dl class="calc__list">';
        rows.forEach(function (r) {
            var parts = [fmt(r.area, 1) + ' m²', 'lauta ' + r.input.thickness + ' × ' + r.input.width + ' mm'];
            if (state.calculators.price || state.calculators.co2 || state.calculators.chemical) {
                parts.push(r.type.label.toLowerCase());
                parts.push(r.finish.label.toLowerCase());
            }
            if (state.calculators.co2) { parts.push('kuljetus ' + r.transport.label.toLowerCase()); }
            entered += '<div><dt>' + esc(r.item.label) + '</dt><dd>' + esc(parts.join(' · ')) + '</dd></div>';
        });
        entered += '<div><dt>Hukkavara</dt><dd>' + esc(fmt(wastePercent(), 0)) + ' %</dd></div>';
        entered += '</dl>';
        html += '<section class="calc__result">' + breakdown('entered', entered, 'Syötetyt arvot') + '</section>';

        resultsBody.innerHTML = html;
        restoreResultsState(wasOpen, focusedTip);
    }

    /* ---------------- Start ---------------- */

    /* Arriving from a front page button preselects that one calculator, so the
       visitor only sees the fields it needs. */
    function applyQuery() {
        var match = /[?&]laskuri=([a-z0-9]+)/i.exec(window.location.search);
        if (!match) { return; }
        var key = QUERY_TO_KEY[match[1].toLowerCase()];
        if (!key) { return; }
        Object.keys(state.calculators).forEach(function (k) {
            state.calculators[k] = (k === key);
        });
        syncCalculatorButtons();
    }

    applyQuery();
    renderPanels();
    calculate();
}());
