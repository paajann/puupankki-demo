document.addEventListener('DOMContentLoaded', function () {

    // Suodatinikkunat
    document.querySelectorAll('[data-dialog]').forEach(function (button) {
        const dialog = document.getElementById(button.dataset.dialog);
        const boxes = dialog.querySelectorAll('input[type="checkbox"]');

        // Closing without pressing "Näytä tulokset" restores the previous selection
        function closeWithoutSaving() {
            boxes.forEach(function (box) {
                box.checked = box.defaultChecked;
            });
            dialog.close();
            button.focus();
        }

        button.addEventListener('click', function () {
            dialog.showModal();
        });

        dialog.querySelector('[data-close]').addEventListener('click', closeWithoutSaving);

        // Esc key
        dialog.addEventListener('cancel', function (event) {
            event.preventDefault();
            closeWithoutSaving();
        });

        // Klikkaus ikkunan ulkopuolelle (tummalle taustalle)
        dialog.addEventListener('click', function (event) {
            if (event.target === dialog) closeWithoutSaving();
        });

        // Clear the selections inside the dialog
        dialog.querySelector('[data-clear]').addEventListener('click', function () {
            boxes.forEach(function (box) {
                box.checked = false;
            });
        });
    });

    // Haku nimen perusteella
    const input = document.getElementById('puu-haku');
    const cards = document.querySelectorAll('.card--species');
    const count = document.getElementById('puu-maara');
    if (!input) return;

    input.addEventListener('input', function () {
        const query = input.value.trim().toLowerCase();
        let shown = 0;

        cards.forEach(function (card) {
            const name = card.querySelector('.card__title').textContent.toLowerCase();
            const match = name.includes(query);
            card.hidden = !match;
            if (match) shown++;
        });

        count.textContent = shown === 0 ? 'Haulla ei löytynyt puulajeja.' : shown + ' puulajia';
    });
});