document.addEventListener('DOMContentLoaded', function () {
    const body = document.body;
    const menuButton = document.querySelector('.menu-toggle');
    const searchButton = document.querySelector('.search-toggle');
    const searchInput = document.querySelector('#site-search input');
    const searchLabel = searchButton ? searchButton.querySelector('.screen-reader-text') : null;

    // Mobiilin Menu-nappi
    if (menuButton) {
        menuButton.addEventListener('click', function () {
            const isOpen = body.classList.toggle('menu-open');
            menuButton.setAttribute('aria-expanded', isOpen);
        });
    }

    // Haku
    function openSearch() {
        body.classList.add('search-open');
        searchButton.setAttribute('aria-expanded', 'true');
        searchLabel.textContent = 'Sulje haku';
        requestAnimationFrame(function () {
            searchInput.focus();
        });
    }

    function closeSearch() {
        body.classList.remove('search-open');
        searchButton.setAttribute('aria-expanded', 'false');
        searchLabel.textContent = 'Avaa haku';
    }

    if (searchButton && searchInput) {
        searchButton.addEventListener('click', function () {
            if (body.classList.contains('search-open')) {
                closeSearch();
            } else {
                openSearch();
            }
        });
    }

    // Esc closes search or the menu and returns focus to the button
    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;

        if (body.classList.contains('search-open')) {
            closeSearch();
            searchButton.focus();
        } else if (body.classList.contains('menu-open')) {
            body.classList.remove('menu-open');
            menuButton.setAttribute('aria-expanded', 'false');
            menuButton.focus();
        }
    });
});