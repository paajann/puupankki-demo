/* Puupankin laskurit – laskenta selaimessa.
   Puulajien luvut ja kertoimet tulevat PHP:stä (puupankkiLaskuri). */
(function () {
    'use strict';

    var juuri = document.getElementById('puupankki-laskurit');
    if (!juuri || typeof puupankkiLaskuri === 'undefined') {
        return;
    }

    var puulajit  = puupankkiLaskuri.puulajit;
    var kertoimet = puupankkiLaskuri.kertoimet;

    // Tila: mitkä laskurit ja materiaalit on valittu, ja mitä kenttiin on syötetty
    var tila = {
        laskurit: { tarve: true, hinta: false, co2: false },
        materiaalit: [],          // puulajien id:t valintajärjestyksessä
        hukka: kertoimet.hukka,
        syotteet: {}              // id -> { ala, leveys, pituus, kasittely, alkupera }
    };

    var paneelit        = document.getElementById('lk-paneelit');
    var tyhja           = document.getElementById('lk-tyhja');
    var tuloksetSisalto = document.getElementById('lk-tulokset-sisalto');
    var tuloksetTyhja   = document.getElementById('lk-tulokset-tyhja');

    function haePuu(id) {
        for (var i = 0; i < puulajit.length; i++) {
            if (puulajit[i].id === id) { return puulajit[i]; }
        }
        return null;
    }

    function oletusSyote() {
        return {
            ala: '',
            leveys: kertoimet.leveydet[1],
            pituus: kertoimet.pituudet[1],
            kasittely: 'raakapuu',
            alkupera: 'kotimainen'
        };
    }

    function fmt(luku, desimaalit) {
        return new Intl.NumberFormat('fi-FI', {
            minimumFractionDigits: desimaalit,
            maximumFractionDigits: desimaalit
        }).format(luku);
    }

    function esc(teksti) {
        return String(teksti).replace(/[&<>"']/g, function (m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
        });
    }

    /* ---------------- Valintanapit ---------------- */

    juuri.querySelectorAll('[data-laskuri]').forEach(function (nappi) {
        nappi.addEventListener('click', function () {
            var avain = nappi.getAttribute('data-laskuri');
            tila.laskurit[avain] = !tila.laskurit[avain];
            nappi.classList.toggle('is-active', tila.laskurit[avain]);
            nappi.setAttribute('aria-pressed', tila.laskurit[avain] ? 'true' : 'false');
            piirraPaneelit();
            laske();
        });
    });

    juuri.querySelectorAll('[data-materiaali]').forEach(function (nappi) {
        nappi.addEventListener('click', function () {
            var id = nappi.getAttribute('data-materiaali');
            var kohta = tila.materiaalit.indexOf(id);
            if (kohta === -1) {
                tila.materiaalit.push(id);
                if (!tila.syotteet[id]) { tila.syotteet[id] = oletusSyote(); }
            } else {
                tila.materiaalit.splice(kohta, 1);
            }
            var valittu = kohta === -1;
            nappi.classList.toggle('is-active', valittu);
            nappi.setAttribute('aria-pressed', valittu ? 'true' : 'false');
            piirraPaneelit();
            laske();
        });
    });

    /* ---------------- Paneelit (kentät) ---------------- */

    function chipRyhma(nimi, id, vaihtoehdot, valittu) {
        var html = '<div class="lk__chipit" role="group" aria-label="' + esc(nimi) + '">';
        Object.keys(vaihtoehdot).forEach(function (avain) {
            var aktiivinen = avain === valittu ? ' is-active' : '';
            html += '<button type="button" class="lk__chip' + aktiivinen + '" data-kentta="' + esc(id) + '" data-arvo="' + esc(avain) + '" aria-pressed="' + (avain === valittu) + '">' + esc(vaihtoehdot[avain].nimi) + '</button>';
        });
        return html + '</div>';
    }

    var VALITSE = '<p class="lk__ohje lk__ohje--paneeli">Valitse materiaali yllä, niin kentät tulevat näkyviin.</p>';

    function piirraPaneelit() {
        var onMateriaaleja = tila.materiaalit.length > 0;
        tyhja.hidden = true;

        var html = '';

        // Yhteinen paneeli: pinta-ala joka materiaalille
        html += '<section class="lk__paneeli"><h3 class="lk__paneeli-otsikko">Materiaalin määrä</h3>';
        if (!onMateriaaleja) { html += VALITSE; }
        tila.materiaalit.forEach(function (id) {
            var puu = haePuu(id), s = tila.syotteet[id];
            html += '<div class="lk__rivi"><label class="lk__label" for="ala-' + esc(id) + '">' + esc(puu.nimi) + '</label>'
                  + '<div class="lk__kentta"><input type="number" id="ala-' + esc(id) + '" inputmode="decimal" min="0" step="0.1" placeholder="0" value="' + esc(s.ala) + '" data-ala="' + esc(id) + '"><span class="lk__yksikko">m²</span></div></div>';
        });
        html += '</section>';

        // Materiaalin tarve: laudan koko ja hukka
        if (tila.laskurit.tarve) {
            html += '<section class="lk__paneeli lk__paneeli--tarve"><h3 class="lk__paneeli-otsikko">Materiaalin tarve</h3>';
            html += '<div class="lk__rivi"><label class="lk__label" for="lk-hukka">Hukkavara</label>'
                  + '<div class="lk__kentta"><input type="number" id="lk-hukka" inputmode="numeric" min="0" max="50" step="1" value="' + esc(tila.hukka) + '" data-hukka><span class="lk__yksikko">%</span></div></div>';
            if (!onMateriaaleja) { html += VALITSE; }
            tila.materiaalit.forEach(function (id) {
                var puu = haePuu(id), s = tila.syotteet[id];
                html += '<div class="lk__rivi lk__rivi--pino"><span class="lk__label">' + esc(puu.nimi) + ' – laudan koko</span><div class="lk__valinnat-rivi">';
                html += '<label class="lk__select"><span>Leveys</span><select data-leveys="' + esc(id) + '">';
                kertoimet.leveydet.forEach(function (l) {
                    html += '<option value="' + l + '"' + (Number(s.leveys) === l ? ' selected' : '') + '>' + l + ' mm</option>';
                });
                html += '</select></label>';
                html += '<label class="lk__select"><span>Pituus</span><select data-pituus="' + esc(id) + '">';
                kertoimet.pituudet.forEach(function (p) {
                    html += '<option value="' + p + '"' + (Number(s.pituus) === p ? ' selected' : '') + '>' + fmt(p, 1) + ' m</option>';
                });
                html += '</select></label></div></div>';
            });
            html += '</section>';
        }

        // Hinta-arvio: käsittely
        if (tila.laskurit.hinta) {
            html += '<section class="lk__paneeli lk__paneeli--hinta"><h3 class="lk__paneeli-otsikko">Hinta-arvio</h3><p class="lk__ohje">Käsittely vaikuttaa hintaan ja päästöihin.</p>';
            if (!onMateriaaleja) { html += VALITSE; }
            tila.materiaalit.forEach(function (id) {
                var puu = haePuu(id), s = tila.syotteet[id];
                html += '<div class="lk__rivi lk__rivi--pino"><span class="lk__label">' + esc(puu.nimi) + ' – käsittely</span>'
                      + chipRyhma(puu.nimi + ' käsittely', 'kasittely:' + id, kertoimet.kasittelyt, s.kasittely) + '</div>';
            });
            html += '</section>';
        }

        // Hiilijalanjälki: alkuperä
        if (tila.laskurit.co2) {
            html += '<section class="lk__paneeli lk__paneeli--co2"><h3 class="lk__paneeli-otsikko">Hiilijalanjälki</h3><p class="lk__ohje">Tuontipuun kuljetus lisää päästöjä.</p>';
            if (!onMateriaaleja) { html += VALITSE; }
            tila.materiaalit.forEach(function (id) {
                var puu = haePuu(id), s = tila.syotteet[id];
                html += '<div class="lk__rivi lk__rivi--pino"><span class="lk__label">' + esc(puu.nimi) + ' – alkuperä</span>'
                      + chipRyhma(puu.nimi + ' alkuperä', 'alkupera:' + id, kertoimet.alkuperat, s.alkupera) + '</div>';
            });
            html += '</section>';
        }

        paneelit.innerHTML = html;
    }

    // Kenttien muutokset: päivitetään tila ja lasketaan uudelleen (ei piirretä paneeleja uusiksi)
    paneelit.addEventListener('input', function (e) {
        var k = e.target;
        if (k.hasAttribute('data-ala'))    { tila.syotteet[k.getAttribute('data-ala')].ala = k.value; }
        if (k.hasAttribute('data-hukka'))  { tila.hukka = k.value; }
        laske();
    });
    paneelit.addEventListener('change', function (e) {
        var k = e.target;
        if (k.hasAttribute('data-leveys')) { tila.syotteet[k.getAttribute('data-leveys')].leveys = k.value; }
        if (k.hasAttribute('data-pituus')) { tila.syotteet[k.getAttribute('data-pituus')].pituus = k.value; }
        laske();
    });
    paneelit.addEventListener('click', function (e) {
        var chip = e.target.closest('.lk__chip');
        if (!chip) { return; }
        var osat = chip.getAttribute('data-kentta').split(':');
        tila.syotteet[osat[1]][osat[0]] = chip.getAttribute('data-arvo');
        chip.parentNode.querySelectorAll('.lk__chip').forEach(function (c) {
            var aktiivinen = c === chip;
            c.classList.toggle('is-active', aktiivinen);
            c.setAttribute('aria-pressed', aktiivinen ? 'true' : 'false');
        });
        laske();
    });

    /* ---------------- Laskenta ---------------- */

    function laske() {
        var rivit = [];
        tila.materiaalit.forEach(function (id) {
            var puu = haePuu(id), s = tila.syotteet[id];
            var ala = parseFloat(String(s.ala).replace(',', '.'));
            if (!(ala > 0)) { return; }

            var hukka    = Math.max(0, parseFloat(tila.hukka) || 0) / 100;
            var kasittely = kertoimet.kasittelyt[s.kasittely];
            var alkupera  = kertoimet.alkuperat[s.alkupera];

            // Materiaalin tarve: m² -> juoksumetrit (hukka mukana) -> laudat kpl
            var leveysM = Number(s.leveys) / 1000;
            var jm      = ala / leveysM * (1 + hukka);
            var kpl     = Math.ceil(jm / Number(s.pituus));

            // Hinta: m² × viitehinta × käsittelykerroin (hukka mukana, koska lautoja ostetaan hukan verran enemmän)
            var hintaPerM2 = puu.hinta * kasittely.hinta;
            var hinta      = ala * (1 + hukka) * hintaPerM2;

            // Hiilijalanjälki: m² × päästökerroin × alkuperä × käsittely (hukka mukana)
            var co2PerM2 = puu.co2 * alkupera.co2 * kasittely.co2;
            var co2      = ala * (1 + hukka) * co2PerM2;

            rivit.push({ puu: puu, s: s, ala: ala, jm: jm, kpl: kpl, hintaPerM2: hintaPerM2, hinta: hinta, co2PerM2: co2PerM2, co2: co2 });
        });

        piirraTulokset(rivit);
    }

    // Asteikkopalkki: missä valinta on kevyimmän ja raskaimman puulajin välillä
    function asteikko(arvo, avain, yksikko, desimaalit) {
        var min = null, max = null;
        puulajit.forEach(function (p) {
            if (min === null || p[avain] < min[avain]) { min = p; }
            if (max === null || p[avain] > max[avain]) { max = p; }
        });
        if (!min || !max || max[avain] === min[avain]) { return ''; }
        var osuus = Math.min(1, Math.max(0, (arvo - min[avain]) / (max[avain] - min[avain])));
        var sana  = osuus < 0.33 ? 'kevyimpien joukossa' : (osuus < 0.66 ? 'asteikon keskivaiheilla' : 'raskaimpien joukossa');
        if (avain === 'hinta') { sana = osuus < 0.33 ? 'edullisimpien joukossa' : (osuus < 0.66 ? 'keskihintainen' : 'kalleimpien joukossa'); }
        return '<div class="lk__asteikko" aria-label="Valintasi on ' + esc(sana) + '">'
             + '<div class="lk__asteikko-palkki"><span class="lk__asteikko-merkki" style="left:' + (osuus * 100).toFixed(1) + '%"></span></div>'
             + '<div class="lk__asteikko-paat"><span>' + esc(min.nimi) + ' ' + esc(fmt(min[avain], desimaalit)) + ' ' + esc(yksikko) + '</span><span>' + esc(max.nimi) + ' ' + esc(fmt(max[avain], desimaalit)) + ' ' + esc(yksikko) + '</span></div>'
             + '<p class="lk__selite">Valintasi on ' + esc(sana) + ' (' + esc(fmt(arvo, desimaalit)) + ' ' + esc(yksikko) + ' keskimäärin).</p>'
             + '</div>';
    }

    function erittely(sisalto) {
        return '<details class="lk__erittely"><summary>Näytä erittely</summary>' + sisalto + '</details>';
    }

    function piirraTulokset(rivit) {
        if (!rivit.length) {
            tuloksetSisalto.innerHTML = '';
            tuloksetTyhja.hidden = false;
            return;
        }
        tuloksetTyhja.hidden = true;

        var html = '';
        var alaYht = 0;
        rivit.forEach(function (r) { alaYht += r.ala * (1 + (Math.max(0, parseFloat(tila.hukka) || 0) / 100)); });

        // Materiaalin tarve
        if (tila.laskurit.tarve) {
            var kplYht = 0, jmYht = 0, rivitHtml = '';
            rivit.forEach(function (r) {
                kplYht += r.kpl; jmYht += r.jm;
                rivitHtml += '<div class="lk__tulos-rivi"><span class="lk__tulos-nimi">' + esc(r.puu.nimi) + '</span>'
                           + '<span class="lk__tulos-arvo">' + esc(r.kpl) + ' lautaa<small>' + esc(fmt(r.jm, 1)) + ' jm · ' + esc(r.s.leveys) + ' mm × ' + esc(fmt(Number(r.s.pituus), 1)) + ' m</small></span></div>';
            });
            html += '<section class="lk__tulos"><h3 class="lk__tulos-otsikko">Materiaalin tarve <span class="lk__info" tabindex="0" aria-label="Laskentatapa: pinta-ala jaettuna laudan leveydellä, hukkavara lisättynä, pyöristetty täysiin lautoihin.">i</span></h3>'
                  + '<p class="lk__iso"><strong>' + esc(kplYht) + ' lautaa</strong><span>' + esc(fmt(jmYht, 0)) + ' juoksumetriä, hukkavara ' + esc(fmt(parseFloat(tila.hukka) || 0, 0)) + ' % mukana</span></p>'
                  + (rivit.length > 1 ? erittely(rivitHtml) : '')
                  + '</section>';
        }

        // Hinta-arvio
        if (tila.laskurit.hinta) {
            var yhteensa = 0, rivitHinta = '';
            rivit.forEach(function (r) {
                yhteensa += r.hinta;
                rivitHinta += '<div class="lk__tulos-rivi"><span class="lk__tulos-nimi">' + esc(r.puu.nimi) + '</span>'
                            + '<span class="lk__tulos-arvo">' + esc(fmt(r.hinta, 2)) + ' €<small>' + esc(fmt(r.hintaPerM2, 2)) + ' € / m² · ' + esc(kertoimet.kasittelyt[r.s.kasittely].nimi.toLowerCase()) + '</small></span></div>';
            });
            html += '<section class="lk__tulos"><h3 class="lk__tulos-otsikko">Hinta-arvio <span class="lk__info" tabindex="0" aria-label="Laskentatapa: pinta-ala kertaa viitehinta per neliömetri, käsittelyn kerroin ja hukkavara mukana. Viitehinnat ovat arvioita.">i</span></h3>'
                  + '<p class="lk__iso"><strong>' + esc(fmt(yhteensa, 0)) + ' €</strong><span>noin ' + esc(fmt(yhteensa / alaYht, 2)) + ' € / m²</span></p>'
                  + asteikko(yhteensa / alaYht, 'hinta', '€/m²', 0)
                  + erittely(rivitHinta)
                  + '</section>';
        }

        // Hiilijalanjälki
        if (tila.laskurit.co2) {
            var co2Yhteensa = 0, suurinCo2 = 0, rivitCo2 = '';
            rivit.forEach(function (r) {
                co2Yhteensa += r.co2; suurinCo2 = Math.max(suurinCo2, r.co2PerM2);
                rivitCo2 += '<div class="lk__tulos-rivi"><span class="lk__tulos-nimi">' + esc(r.puu.nimi) + '</span>'
                          + '<span class="lk__tulos-arvo">' + esc(fmt(r.co2, 1)) + ' kg<small>' + esc(fmt(r.co2PerM2, 2)) + ' kg / m² · ' + esc(kertoimet.alkuperat[r.s.alkupera].nimi.toLowerCase()) + '</small></span></div>';
            });
            var autoKm     = co2Yhteensa / (kertoimet.auto_g_per_km / 1000);
            var hiilivarasto = alaYht * kertoimet.hiilivarasto;

            html += '<section class="lk__tulos"><h3 class="lk__tulos-otsikko">Hiilijalanjälki <span class="lk__info" tabindex="0" aria-label="Laskentatapa: pinta-ala kertaa päästökerroin per neliömetri, alkuperän ja käsittelyn kertoimet mukana. Kertoimet perustuvat tyypillisiin EPD-arvoihin. Autovertailu: ' + esc(kertoimet.auto_g_per_km) + ' g CO2e/km.">i</span></h3>'
                  + '<p class="lk__iso"><strong>' + esc(fmt(co2Yhteensa, 0)) + ' kg CO₂e</strong><span>vastaa noin ' + esc(fmt(autoKm, 0)) + ' km ajoa henkilöautolla</span></p>'
                  + asteikko(co2Yhteensa / alaYht, 'co2', 'kg/m²', 2)
                  + '<p class="lk__selite lk__selite--plus">Puu myös varastoi hiiltä: tämä määrä sitoo noin ' + esc(fmt(hiilivarasto, 0)) + ' kg CO₂ niin kauan kuin se on käytössä.</p>';

            var paras = null;
            puulajit.forEach(function (p) {
                if (tila.materiaalit.indexOf(p.id) !== -1) { return; }
                if (p.co2 < suurinCo2 && (!paras || p.co2 < paras.co2)) { paras = p; }
            });
            if (paras) {
                html += '<p class="lk__vinkki">Kevyempi vaihtoehto: <a href="' + esc(paras.url) + '">' + esc(paras.nimi) + '</a>, ' + esc(fmt(paras.co2, 2)) + ' kg CO₂e / m² kotimaisena raakapuuna.</p>';
            }
            html += erittely(rivitCo2) + '</section>';
        }

        // Syötetyt arvot – jotta ei tarvitse muistella, millä luvuilla tulos saatiin
        var syotteet = '<dl class="lk__lista">';
        rivit.forEach(function (r) {
            var osat = [fmt(r.ala, 1) + ' m²'];
            if (tila.laskurit.tarve) { osat.push('lauta ' + r.s.leveys + ' mm × ' + fmt(Number(r.s.pituus), 1) + ' m'); }
            if (tila.laskurit.hinta) { osat.push(kertoimet.kasittelyt[r.s.kasittely].nimi.toLowerCase()); }
            if (tila.laskurit.co2)   { osat.push(kertoimet.alkuperat[r.s.alkupera].nimi.toLowerCase()); }
            syotteet += '<div><dt>' + esc(r.puu.nimi) + '</dt><dd>' + esc(osat.join(' · ')) + '</dd></div>';
        });
        if (tila.laskurit.tarve) {
            syotteet += '<div><dt>Hukkavara</dt><dd>' + esc(fmt(parseFloat(tila.hukka) || 0, 0)) + ' %</dd></div>';
        }
        syotteet += '</dl>';
        html += '<section class="lk__tulos"><details class="lk__erittely"><summary>Syötetyt arvot</summary>' + syotteet + '</details></section>';

        tuloksetSisalto.innerHTML = html;
    }

    piirraPaneelit();
    laske();
})();
