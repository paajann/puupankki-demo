document.addEventListener('DOMContentLoaded', function () {
    const select = document.getElementById('kaupunki');
    if (!select) return;

    const lists = document.querySelectorAll('.stores__list');

    // Näytetään vain valitun kaupungin liikkeet
    select.addEventListener('change', function () {
        lists.forEach(function (list) {
            list.hidden = list.dataset.city !== select.value;
        });
    });
});