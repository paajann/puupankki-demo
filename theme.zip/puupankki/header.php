<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#content">Siirry sisältöön</a>

<header id="site-header">
    <div class="header-inner">
        <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo get_template_directory_uri(); ?>/images/logo.svg" alt="<?php bloginfo('name'); ?>">
        </a>

        <div class="header-tools">
            <nav id="main-nav" aria-label="Päävalikko">
                <?php wp_nav_menu([ 'theme_location' => 'primary', 'container' => false ]); ?>
            </nav>

            <div id="site-search" class="header-search">
                <?php get_search_form(); ?>
            </div>

            <button class="icon-button search-toggle" aria-expanded="false" aria-controls="site-search">
                <svg class="icon-search" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <svg class="icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                <span class="screen-reader-text">Avaa haku</span>
            </button>
        </div>
    </div>
</header>