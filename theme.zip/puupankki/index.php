<?php get_header(); ?>

<main id="content" class="container page-content">

    <h1 class="page-title">
        <?php
        if (is_home()) {
            echo esc_html(get_the_title(get_option('page_for_posts')));
        } elseif (is_search()) {
            printf('Haulla "%s" löytyi %d tulosta', esc_html(get_search_query()), (int) $wp_query->found_posts);
        } else {
            echo esc_html(get_the_archive_title());
        }
        ?>
    </h1>

    <?php the_archive_description('<div class="archive-description">', '</div>'); ?>

    <?php if (have_posts()) : ?>
        <div class="card-list card-list--grid">
            <?php while (have_posts()) : the_post();
                $tyyppi = get_post_type();
                $kortti = in_array($tyyppi, [ 'projekti', 'video', 'puulaji' ]) ? $tyyppi : 'artikkeli';
                get_template_part('template-parts/card', $kortti);
            endwhile; ?>
        </div>

        <?php the_posts_pagination([
            'prev_text'          => 'Edellinen',
            'next_text'          => 'Seuraava',
            'before_page_number' => '<span class="screen-reader-text">Sivu </span>',
        ]); ?>

    <?php else : ?>
        <p>
            <?php echo is_search()
                ? 'Haulla ei löytynyt mitään. Kokeile toista hakusanaa.'
                : 'Täällä ei ole vielä sisältöä.'; ?>
        </p>
    <?php endif; ?>

</main>

<?php get_footer(); ?>