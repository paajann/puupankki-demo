<?php get_header(); ?>

<main id="content" class="container page-content">
<?php while (have_posts()) : the_post();
    // A page holding a catalogue shortcode gets the full width; others keep the reading width
    $content = get_the_content();
    $width  = (has_shortcode($content, 'ohjekauppa') || has_shortcode($content, 'laskurit')) ? ' single-article--wide' : '';
    ?>
    <article class="single-article<?php echo $width; ?>">
        <h1 class="page-title"><?php the_title(); ?></h1>

        <?php if (has_post_thumbnail()) : ?>
            <figure class="single-image"><?php the_post_thumbnail('large'); ?></figure>
        <?php endif; ?>

        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    </article>
<?php endwhile; ?>
</main>

<?php get_footer(); ?>