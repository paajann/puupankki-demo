<?php get_header(); ?>

<main id="content" class="container page-content">
<?php while (have_posts()) : the_post();
    // Ohjekauppa-lyhytkoodin sisältävä sivu saa koko leveyden, muut lukuleveyden
    $sisalto = get_the_content();
    $leveys  = (has_shortcode($sisalto, 'ohjekauppa') || has_shortcode($sisalto, 'laskurit')) ? ' single-article--wide' : '';
    ?>
    <article class="single-article<?php echo $leveys; ?>">
        <h1 class="page-title"><?php the_title(); ?></h1>

        <?php if (has_post_thumbnail()) : ?>
            <figure class="single-image"><?php the_post_thumbnail('large'); ?></figure>
        <?php endif; ?>

        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    </article>
<?php endwhile; ?>
</main>

<?php get_footer(); ?>