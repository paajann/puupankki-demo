<?php get_header(); ?>

<main id="content" class="container page-content">
<div class="single-layout">
<?php while (have_posts()) : the_post();
    $type = get_post_type();

    // "Palaa takaisin" -linkki oikeaan listaukseen
    if ($type === 'post') {
        $back_url = get_permalink(get_option('page_for_posts'));
        $back_text = 'Kaikki artikkelit';
    } elseif ($type === 'rakennusohje' && ($guide_shop = get_page_by_path('ohjekauppa'))) {
        // Building guides link back to the catalogue page, not to the archive
        $back_url = get_permalink($guide_shop);
        $back_text = 'Ohjekauppa';
    } else {
        $back_url = get_post_type_archive_link($type);
        $back_text = 'Kaikki ' . mb_strtolower(get_post_type_object($type)->labels->name);
    }
    ?>

    <article class="single-article">
        <a class="back-link" href="<?php echo esc_url($back_url); ?>"><?php echo esc_html($back_text); ?></a>

        <header class="single-header">
            <?php if ($type === 'post') : ?>
                <p class="single-label"><?php the_category(', '); ?></p>
            <?php elseif ($type === 'video') :
                $topics = get_the_terms(get_the_ID(), 'videoaihe');
                if ($topics && !is_wp_error($topics)) : ?>
                    <p class="single-label"><?php echo esc_html($topics[0]->name); ?></p>
                <?php endif;
            endif; ?>

            <h1><?php the_title(); ?></h1>

            <?php if ($type === 'post') : ?>
                <p class="single-meta">
                    <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo get_the_date(); ?></time>
                </p>
            <?php endif; ?>
        </header>

        <?php // On a video page the video sits in the content, so no featured image
        if (has_post_thumbnail() && $type !== 'video') : ?>
            <figure class="single-image">
                <?php the_post_thumbnail('large'); ?>
            </figure>
        <?php endif; ?>

        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    </article>

<?php endwhile; ?>

    <?php if (is_active_sidebar('sivupalkki')) : ?>
        <aside class="single-sidebar" aria-label="Sivupalkki">
            <?php dynamic_sidebar('sivupalkki'); ?>
        </aside>
    <?php endif; ?>
</div>
</main>

<?php get_footer(); ?>