<?php get_header(); ?>

<main id="content" class="container page-content">
<div class="single-layout">
<?php while (have_posts()) : the_post();
    $tyyppi = get_post_type();

    // "Palaa takaisin" -linkki oikeaan listaukseen
    if ($tyyppi === 'post') {
        $takaisin = get_permalink(get_option('page_for_posts'));
        $takaisin_teksti = 'Kaikki artikkelit';
    } elseif ($tyyppi === 'rakennusohje' && ($ohjekauppa = get_page_by_path('ohjekauppa'))) {
        // Rakennusohjeista palataan Ohjekauppa-sivulle, ei arkistoon
        $takaisin = get_permalink($ohjekauppa);
        $takaisin_teksti = 'Ohjekauppa';
    } else {
        $takaisin = get_post_type_archive_link($tyyppi);
        $takaisin_teksti = 'Kaikki ' . mb_strtolower(get_post_type_object($tyyppi)->labels->name);
    }
    ?>

    <article class="single-article">
        <a class="back-link" href="<?php echo esc_url($takaisin); ?>"><?php echo esc_html($takaisin_teksti); ?></a>

        <header class="single-header">
            <?php if ($tyyppi === 'post') : ?>
                <p class="single-label"><?php the_category(', '); ?></p>
            <?php elseif ($tyyppi === 'video') :
                $aiheet = get_the_terms(get_the_ID(), 'videoaihe');
                if ($aiheet && !is_wp_error($aiheet)) : ?>
                    <p class="single-label"><?php echo esc_html($aiheet[0]->name); ?></p>
                <?php endif;
            endif; ?>

            <h1><?php the_title(); ?></h1>

            <?php if ($tyyppi === 'post') : ?>
                <p class="single-meta">
                    <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo get_the_date(); ?></time>
                </p>
            <?php endif; ?>
        </header>

        <?php // Videosivulla video on sisällössä, joten artikkelikuvaa ei näytetä
        if (has_post_thumbnail() && $tyyppi !== 'video') : ?>
            <figure class="single-image">
                <?php the_post_thumbnail('large'); ?>
            </figure>
        <?php endif; ?>

        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    </article>

<?php endwhile; ?>

    <?php if (is_active_sidebar('sivupalkki')) : ?>
        <aside class="single-sidebar" aria-label="Sivupalkki">
            <?php dynamic_sidebar('sivupalkki'); ?>
        </aside>
    <?php endif; ?>
</div>
</main>

<?php get_footer(); ?>