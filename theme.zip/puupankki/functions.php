<?php
function puupankki_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', [ 'search-form' ]);
    register_nav_menus([ 'primary' => 'Päävalikko' ]);
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'puupankki_setup');

function puupankki_assets() {
    wp_enqueue_style('puupankki-fonts', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap', [], null);
    wp_enqueue_style('puupankki-style', get_stylesheet_uri());
    wp_enqueue_script('puupankki-nav', get_template_directory_uri() . '/js/navigation.js', [], '1.0', true);
            if (is_front_page() || is_singular('puulaji')) {
        wp_enqueue_script('puupankki-carousel', get_template_directory_uri() . '/js/carousel.js', [], '1.0', true);
    }

    if (is_singular('puulaji')) {
        wp_enqueue_script('puupankki-puusivu', get_template_directory_uri() . '/js/puusivu.js', [], '1.0', true);
    }
        if (is_post_type_archive('puulaji')) {
        wp_enqueue_script('puupankki-puulajit', get_template_directory_uri() . '/js/puulajit.js', [], '1.0', true);
    }
}
add_action('wp_enqueue_scripts', 'puupankki_assets');

/* Omat sisältötyypit */
function puupankki_post_types() {

    register_post_type('projekti', [
        'labels' => [
            'name' => 'Projektit',
            'singular_name' => 'Projekti',
            'add_new_item' => 'Lisää uusi projekti',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => [ 'slug' => 'projektit' ],
        'menu_icon' => 'dashicons-hammer',
        'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail' ],
        'show_in_rest' => true,
    ]);

    register_post_type('puulaji', [
        'labels' => [
            'name' => 'Puulajit',
            'singular_name' => 'Puulaji',
            'add_new_item' => 'Lisää uusi puulaji',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => [ 'slug' => 'puulajit' ],
        'menu_icon' => 'dashicons-palmtree',
        'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    register_post_type('video', [
        'labels' => [
            'name' => 'Video-ohjeet',
            'singular_name' => 'Video-ohje',
            'add_new_item' => 'Lisää uusi video-ohje',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => [ 'slug' => 'video-ohjeet' ],
        'menu_icon' => 'dashicons-video-alt3',
        'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail' ],
        'show_in_rest' => true,
    ]);
}
add_action('init', 'puupankki_post_types');

/* Puulajien suodattimet ja video-ohjeiden aiheet */
function puupankki_taxonomies() {

    register_taxonomy('ominaisuus', 'puulaji', [
        'labels' => [ 'name' => 'Ominaisuudet', 'singular_name' => 'Ominaisuus' ],
        'hierarchical' => true,
        'show_in_rest' => true,
    ]);

    register_taxonomy('kayttotarkoitus', 'puulaji', [
        'labels' => [ 'name' => 'Käyttötarkoitukset', 'singular_name' => 'Käyttötarkoitus' ],
        'hierarchical' => true,
        'show_in_rest' => true,
    ]);

    register_taxonomy('videoaihe', 'video', [
        'labels' => [ 'name' => 'Aiheet', 'singular_name' => 'Aihe' ],
        'hierarchical' => true,
        'show_in_rest' => true,
    ]);
}
add_action('init', 'puupankki_taxonomies');
/* Puulajien suodatus ja järjestys */
function puupankki_suodata_puulajit($query) {
    if (is_admin() || !$query->is_main_query() || !$query->is_post_type_archive('puulaji')) {
        return;
    }

    $tax_query = [ 'relation' => 'AND' ];

    // Ominaisuudet: ryhmän sisällä "tai", ryhmien välillä "ja"
    if (!empty($_GET['om'])) {
        $ryhmittain = [];
        foreach ((array) $_GET['om'] as $slug) {
            $termi = get_term_by('slug', sanitize_title($slug), 'ominaisuus');
            if ($termi) {
                $ryhmittain[$termi->parent][] = $termi->slug;
            }
        }
        foreach ($ryhmittain as $slugit) {
            $tax_query[] = [
                'taxonomy' => 'ominaisuus',
                'field'    => 'slug',
                'terms'    => $slugit,
                'operator' => 'IN',
            ];
        }
    }

    // Käyttötarkoitus: mikä tahansa valituista
    if (!empty($_GET['kt'])) {
        $tax_query[] = [
            'taxonomy' => 'kayttotarkoitus',
            'field'    => 'slug',
            'terms'    => array_map('sanitize_title', (array) $_GET['kt']),
            'operator' => 'IN',
        ];
    }

    if (count($tax_query) > 1) {
        $query->set('tax_query', $tax_query);
    }

    $query->set('posts_per_page', -1);
    $query->set('orderby', 'title');
    $query->set('order', 'ASC');
}
add_action('pre_get_posts', 'puupankki_suodata_puulajit');

/* Poistetaan arkiston otsikosta etuliite, esim. "Kategoria: " */
add_filter('get_the_archive_title_prefix', '__return_empty_string');

/* Valikossa korostetaan osio, jonka sisällä käyttäjä on */
function puupankki_nav_aktiivinen($classes, $item) {
    $artikkelisivu = (int) get_option('page_for_posts');
    $on_artikkeleissa = is_home() || is_singular('post') || is_category() || is_tag();

    // WordPress merkitsee artikkelisivun virheellisesti aktiiviseksi myös omien sisältötyyppien sivuilla
    if ($item->object === 'page' && (int) $item->object_id === $artikkelisivu) {
        $classes = array_diff($classes, [ 'current_page_parent' ]);
        if ($on_artikkeleissa) {
            $classes[] = 'current-menu-item';
        }
    }

    // Puulajit, Projektit ja Video-ohjeet ovat valikossa omina linkkeinä
    $polku = trailingslashit((string) wp_parse_url($item->url, PHP_URL_PATH));
    foreach ([ 'puulaji', 'projekti', 'video' ] as $tyyppi) {
        $arkiston_polku = trailingslashit((string) wp_parse_url(get_post_type_archive_link($tyyppi), PHP_URL_PATH));
        $on_osiossa = is_singular($tyyppi) || is_post_type_archive($tyyppi);
        if ($on_osiossa && $polku === $arkiston_polku) {
            $classes[] = 'current-menu-item';
        }
    }

    return $classes;
}
add_filter('nav_menu_css_class', 'puupankki_nav_aktiivinen', 10, 2);

/* Laskurit: puulajien luvut, lyhytkoodi [laskurit] ja laskenta */
require_once get_template_directory() . '/inc/laskurit.php';

/* Etusivun Laskurit-osion tekstit muokattavissa Ulkoasu → Mukauta -näkymässä */
function puupankki_customize_laskurit($wp_customize) {
    $wp_customize->add_section('puupankki_laskurit', [
        'title'    => 'Etusivu: Laskurit',
        'priority' => 30,
    ]);

    $wp_customize->add_setting('puupankki_laskurit_otsikko', [
        'default'           => 'Laskurit suunnittelun tueksi',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('puupankki_laskurit_otsikko', [
        'label'   => 'Otsikko',
        'section' => 'puupankki_laskurit',
        'type'    => 'text',
    ]);

    $wp_customize->add_setting('puupankki_laskurit_teksti', [
        'default'           => 'Laskurit auttavat arvioimaan projektin materiaalit ennen kuin tartut sahaan. Materiaalimenekki kertoo, paljonko puuta tarvitset, ja laskureita voi käyttää myös yhdessä – samalla kertaa näet menekin, hinnan ja hiilijalanjäljen.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ]);
    $wp_customize->add_control('puupankki_laskurit_teksti', [
        'label'   => 'Teksti',
        'section' => 'puupankki_laskurit',
        'type'    => 'textarea',
    ]);
}
add_action('customize_register', 'puupankki_customize_laskurit');

/* Vimpainalueet: footerin kolme saraketta, etusivun nostot ja sivupalkki */
function puupankki_widgets_init() {
    for ($i = 1; $i <= 3; $i++) {
        register_sidebar([
            'name'          => 'Footer: sarake ' . $i,
            'id'            => 'footer-' . $i,
            'before_widget' => '<div class="footer-widget">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2>',
            'after_title'   => '</h2>',
        ]);
    }

    // Etusivulla video-ohjeiden jälkeen, samalla osio-otsikolla kuin muut etusivun osiot
    register_sidebar([
        'name'          => 'Etusivu: nostot',
        'id'            => 'etusivu-nostot',
        'description'   => 'Näkyy etusivulla video-ohjeiden alapuolella täydessä leveydessä.',
        'before_widget' => '<section class="front-section front-widget">',
        'after_widget'  => '</section>',
        'before_title'  => '<div class="section-header"><h2>',
        'after_title'   => '</h2></div>',
    ]);

    // Yksittäisen sisällön (artikkeli, rakennusohje, video) oikealla puolella
    register_sidebar([
        'name'          => 'Sivupalkki',
        'id'            => 'sivupalkki',
        'description'   => 'Näkyy yksittäisen artikkelin, rakennusohjeen ja video-ohjeen vieressä.',
        'before_widget' => '<div class="sidebar-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2>',
        'after_title'   => '</h2>',
    ]);
}
add_action('widgets_init', 'puupankki_widgets_init');

?>