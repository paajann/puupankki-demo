<article class="card card--video">
    <div class="card__image">
        <?php if (has_post_thumbnail()) the_post_thumbnail('large', [ 'alt' => '' ]); ?>
        <span class="play-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M10 8l6 4-6 4z" fill="currentColor"/></svg>
        </span>
    </div>
    <div class="card__body">
        <?php
        $aiheet = get_the_terms(get_the_ID(), 'videoaihe');
        if ($aiheet && !is_wp_error($aiheet)) : ?>
            <p class="card__label"><?php echo esc_html($aiheet[0]->name); ?></p>
        <?php endif; ?>
        <h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    </div>
</article>