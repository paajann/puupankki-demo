<article class="card card--article">
    <div class="card__image">
        <?php if (has_post_thumbnail()) the_post_thumbnail('medium_large', [ 'alt' => '' ]); ?>
    </div>
    <div class="card__body">
        <h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p class="card__excerpt"><?php echo wp_trim_words(get_the_excerpt(), 12); ?></p>
        <p class="card__meta"><?php echo get_the_date(); ?></p>
    </div>
</article>