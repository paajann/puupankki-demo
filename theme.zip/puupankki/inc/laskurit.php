<?php
/**
 * Puupankin laskurit: materiaalin tarve, hinta-arvio ja hiilijalanjälki.
 *
 * - Puulaji-sisältöihin tulee metalaatikko "Laskurin luvut" (viitehinta €/m² ja
 *   päästökerroin kg CO2e/m²). Luvut muokataan WordPressistä, ei koodista.
 * - Lyhytkoodi [laskurit] piirtää laskurin. Laskenta tapahtuu selaimessa
 *   (js/laskurit.js), ja puulajien luvut viedään sivulle alla olevasta PHP:stä.
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   1. Laskennan kertoimet yhdessä paikassa
   --------------------------------------------------------------- */
function puupankki_laskuri_kertoimet() {
    return [
        // Hukkaprosentti oletuksena (käyttäjä voi muuttaa)
        'hukka' => 10,

        // Tulosten ymmärrettävyys: vertailuluvut
        'auto_g_per_km'  => 120, // henkilöauton keskipäästö g CO2e/km (uusien autojen suuruusluokka)
        'hiilivarasto'   => 23,  // puun sitoma hiili kg CO2 / m² 28 mm lautaa (havupuu, suuruusluokka)

        // Laudan leveydet (mm) ja pituudet (m), joista käyttäjä valitsee
        'leveydet' => [95, 120, 145],
        'pituudet' => [3.0, 4.2, 4.8],

        // Käsittely: kerroin hintaan ja päästöihin suhteessa raakapuuhun
        'kasittelyt' => [
            'raakapuu'       => ['nimi' => 'Raakapuu',       'hinta' => 1.00, 'co2' => 1.00],
            'hoylatty'       => ['nimi' => 'Höylätty',       'hinta' => 1.15, 'co2' => 1.05],
            'lampokasitelty' => ['nimi' => 'Lämpökäsitelty', 'hinta' => 1.60, 'co2' => 1.30],
        ],

        // Alkuperä: ulkomainen puu lisää kuljetuksen päästöjä
        'alkuperat' => [
            'kotimainen' => ['nimi' => 'Kotimainen', 'hinta' => 1.00, 'co2' => 1.00],
            'ulkomainen' => ['nimi' => 'Ulkomainen', 'hinta' => 0.90, 'co2' => 1.25],
        ],
    ];
}

/* ---------------------------------------------------------------
   2. Puulajin metalaatikko: viitehinta ja päästökerroin
   --------------------------------------------------------------- */
function puupankki_laskuri_meta_box() {
    add_meta_box('puupankki_laskuri_luvut', 'Laskurin luvut', 'puupankki_laskuri_meta_box_html', 'puulaji', 'side');
}
add_action('add_meta_boxes', 'puupankki_laskuri_meta_box');

function puupankki_laskuri_meta_box_html($post) {
    wp_nonce_field('puupankki_laskuri_tallennus', 'puupankki_laskuri_nonce');
    $hinta = get_post_meta($post->ID, '_pp_laskuri_hinta', true);
    $co2   = get_post_meta($post->ID, '_pp_laskuri_co2', true);
    ?>
    <p>
        <label for="pp_laskuri_hinta">Viitehinta (€/m², 28 mm lauta, raakapuu)</label><br>
        <input type="number" id="pp_laskuri_hinta" name="pp_laskuri_hinta" min="0" step="0.01" value="<?php echo esc_attr($hinta); ?>">
    </p>
    <p>
        <label for="pp_laskuri_co2">Päästökerroin (kg CO2e/m², kotimainen raakapuu)</label><br>
        <input type="number" id="pp_laskuri_co2" name="pp_laskuri_co2" min="0" step="0.01" value="<?php echo esc_attr($co2); ?>">
    </p>
    <p class="description">Jos kentät ovat tyhjät, puulaji ei näy laskurissa. Luvut ovat arvioita – tarkista CO2data.fi ja rautakauppojen hinnat.</p>
    <?php
}

function puupankki_laskuri_tallenna($post_id) {
    if (!isset($_POST['puupankki_laskuri_nonce']) || !wp_verify_nonce($_POST['puupankki_laskuri_nonce'], 'puupankki_laskuri_tallennus')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    foreach (['hinta', 'co2'] as $kentta) {
        $arvo = isset($_POST['pp_laskuri_' . $kentta]) ? str_replace(',', '.', $_POST['pp_laskuri_' . $kentta]) : '';
        if ($arvo === '' || !is_numeric($arvo)) {
            delete_post_meta($post_id, '_pp_laskuri_' . $kentta);
        } else {
            update_post_meta($post_id, '_pp_laskuri_' . $kentta, (string) floatval($arvo));
        }
    }
}
add_action('save_post_puulaji', 'puupankki_laskuri_tallenna');

/* ---------------------------------------------------------------
   3. Puulajit laskurille: vain ne, joille luvut on annettu
   --------------------------------------------------------------- */
function puupankki_laskuri_puulajit() {
    $puulajit = get_posts([
        'post_type'   => 'puulaji',
        'numberposts' => -1,
        'orderby'     => 'title',
        'order'       => 'ASC',
        'post_status' => 'publish',
    ]);

    $lista = [];
    foreach ($puulajit as $puu) {
        $hinta = get_post_meta($puu->ID, '_pp_laskuri_hinta', true);
        $co2   = get_post_meta($puu->ID, '_pp_laskuri_co2', true);
        if ($hinta === '' || $co2 === '') {
            continue;
        }
        $lista[] = [
            'id'    => 'puu-' . $puu->ID,
            'nimi'  => $puu->post_title,
            'url'   => get_permalink($puu),
            'hinta' => (float) $hinta,
            'co2'   => (float) $co2,
        ];
    }
    return $lista;
}

/* ---------------------------------------------------------------
   4. Lyhytkoodi [laskurit]
   --------------------------------------------------------------- */
function puupankki_laskurit_lyhytkoodi() {
    $puulajit  = puupankki_laskuri_puulajit();
    $kertoimet = puupankki_laskuri_kertoimet();

    // CSS ja JS vain sivulle, jolla laskuri on
    wp_enqueue_script('puupankki-laskurit', get_template_directory_uri() . '/js/laskurit.js', [], '1.3', true);
    wp_localize_script('puupankki-laskurit', 'puupankkiLaskuri', [
        'puulajit'  => $puulajit,
        'kertoimet' => $kertoimet,
    ]);

    if (!$puulajit) {
        return '<p>Laskuri tarvitsee puulajeille viitehinnan ja päästökertoimen. Lisää ne Puulajit-sisältöihin kohdassa "Laskurin luvut".</p>';
    }

    ob_start();
    ?>
    <div class="lk" id="puupankki-laskurit">

        <!-- VASEN: valinnat -->
        <div class="lk__valinnat">

            <section class="lk__osio" aria-labelledby="lk-laskurit-otsikko">
                <h2 id="lk-laskurit-otsikko" class="lk__otsikko">Valitse laskurit</h2>
                <p class="lk__ohje">Voit valita useamman – ne käyttävät samoja lähtötietoja.</p>
                <div class="lk__napit" role="group" aria-label="Laskurit">
                    <button type="button" class="lk__nappi is-active" data-laskuri="tarve" aria-pressed="true">Materiaalin tarve</button>
                    <button type="button" class="lk__nappi" data-laskuri="hinta" aria-pressed="false">Hinta-arvio</button>
                    <button type="button" class="lk__nappi" data-laskuri="co2" aria-pressed="false">Hiilijalanjälki</button>
                    <span class="lk__nappi is-coming" aria-disabled="true">Kemikaalikuorma <small>Tulossa</small></span>
                </div>
            </section>

            <section class="lk__osio" aria-labelledby="lk-materiaalit-otsikko">
                <h2 id="lk-materiaalit-otsikko" class="lk__otsikko">Valitse materiaalit</h2>
                <div class="lk__napit" role="group" aria-label="Materiaalit">
                    <?php foreach ($puulajit as $puu) : ?>
                        <button type="button" class="lk__nappi" data-materiaali="<?php echo esc_attr($puu['id']); ?>" aria-pressed="false"><?php echo esc_html($puu['nimi']); ?></button>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Laskurikohtaiset paneelit täytetään JavaScriptillä valintojen mukaan -->
            <div class="lk__paneelit" id="lk-paneelit"></div>

            <p class="lk__tyhja" id="lk-tyhja">Valitse vähintään yksi materiaali, niin kentät tulevat näkyviin.</p>
        </div>

        <!-- OIKEA: tulokset -->
        <aside class="lk__tulokset" id="lk-tulokset" aria-live="polite" aria-label="Tulokset">
            <h2 class="lk__otsikko">Tulokset</h2>
            <p class="lk__ohje" id="lk-tulokset-tyhja">Tulokset päivittyvät heti, kun syötät tietoja.</p>
            <div id="lk-tulokset-sisalto"></div>
            <p class="lk__huomautus">Luvut ovat arvioita: hinnat ovat viitehintoja ja päästökertoimet perustuvat tyypillisiin EPD-arvoihin. Tarkista ajantasaiset luvut CO2data.fi-palvelusta ja rautakaupasta.</p>
        </aside>

    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('laskurit', 'puupankki_laskurit_lyhytkoodi');
