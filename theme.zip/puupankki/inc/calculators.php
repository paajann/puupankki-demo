<?php
/**
 * Puupankki calculators: material quantity, price estimate and carbon footprint.
 *
 * - Each wood species gets a "Laskurin luvut" meta box (reference price €/m²
 *   and emission factor kg CO2e/m²). The numbers are edited in WordPress,
 *   not in code.
 * - The [laskurit] shortcode renders the calculator. All arithmetic happens in
 *   the browser (js/calculators.js); this file hands the species data over.
 *
 * Note on naming: post type slugs, meta keys and the shortcode tag stay in
 * Finnish because they are stored in the database. Renaming them would orphan
 * the existing content.
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------------------------------------------------------------
   1. Calculation factors, all in one place
   --------------------------------------------------------------- */
function puupankki_calculator_factors() {
    return [
        // Default waste allowance in percent (the visitor can change it)
        'waste' => 10,

        /* Waste allowance by what the timber is used for, so the visitor does
           not have to know a percentage. Rough rules of thumb: the more cutting
           to length and fitting a job needs, the more offcuts it leaves. */
        'waste_presets' => [
            'piharakentaminen' => ['label' => 'Piharakentaminen', 'waste' => 25],
            'ulkoverhous'      => ['label' => 'Ulkoverhous',      'waste' => 15],
            'rakenteet'        => ['label' => 'Rakenteet',        'waste' => 10],
            'sisatilat'        => ['label' => 'Sisätilat',        'waste' => 10],
        ],

        // Comparison figures that make the results easier to grasp
        'car_g_per_km'   => 120, // average car emission, g CO2e/km
        'carbon_storage' => 900, // carbon stored in wood, kg CO2 per m³

        /* Transport: sawn softwood weighs roughly 500 kg/m³, and lorry freight
           is in the order of 0.1 kg CO2e per tonne-kilometre. The distances are
           the midpoint of each band. */
        'timber_density'    => 500,
        'freight_kg_per_tkm' => 0.1,
        'transport' => [
            'none' => ['label' => 'Ei kuljetusta', 'km' => 0],
            'near' => ['label' => 'Alle 50 km',    'km' => 25],
            'mid'  => ['label' => '50–200 km',     'km' => 125],
            'far'  => ['label' => 'Yli 200 km',    'km' => 400],
        ],

        // Board thicknesses and widths (mm) the visitor can pick from
        'thicknesses' => [21, 28, 32, 45],
        'widths'      => [95, 120, 145, 195],

        /* Type of timber: multiplier for price and emissions relative to raw
           timber. 'chemical' feeds the chemical load estimate: 0 = none,
           3 = preservative-treated. */
        'types' => [
            'raakapuu'         => ['label' => 'Raakapuu',         'price' => 1.00, 'co2' => 1.00, 'chemical' => 0],
            'hoylatty'         => ['label' => 'Höylätty',         'price' => 1.15, 'co2' => 1.05, 'chemical' => 0],
            'lampokasitelty'   => ['label' => 'Lämpökäsitelty',   'price' => 1.60, 'co2' => 1.30, 'chemical' => 0],
            'painekyllastetty' => ['label' => 'Painekyllästetty', 'price' => 1.25, 'co2' => 1.20, 'chemical' => 3],
        ],

        /* Surface finish is bought and applied by the square metre, so its price
           and emissions are per m² of surface, not per m³ of timber. */
        'finishes' => [
            'ei'        => ['label' => 'Ei pintakäsittelyä', 'price' => 0.00, 'co2' => 0.00, 'chemical' => 0],
            'puuoljy'   => ['label' => 'Puuöljy',            'price' => 2.00, 'co2' => 0.30, 'chemical' => 1],
            'puunsuoja' => ['label' => 'Kuultava puunsuoja', 'price' => 2.50, 'co2' => 0.40, 'chemical' => 2],
            'maali'     => ['label' => 'Peittävä maali',     'price' => 4.00, 'co2' => 0.60, 'chemical' => 2],
        ],

        /* Chemical load is reported as one of three levels rather than a number,
           because there is no source for reliable per-product quantities. The
           score is the timber type plus the finish. */
        'chemical_levels' => [
            [
                'max'     => 0,
                'label'   => 'Vähäinen',
                'summary' => 'Käsittelemätöntä puuta. Ei erityisiä varotoimia.',
                'advice'  => 'Puupöly ärsyttää hengitysteitä, joten käytä hengityssuojainta sahatessa ja hiotessa. Puhtaan puun voi polttaa tai kompostoida.',
            ],
            [
                'max'     => 2,
                'label'   => 'Kohtalainen',
                'summary' => 'Pintakäsittelyaineita, jotka haihtuvat kuivuessaan.',
                'advice'  => 'Käsittele ulkona tai tuuletetussa tilassa ja käytä suojakäsineitä. Kuivuneet jäännökset ovat sekajätettä, mutta ylijäänyt maali tai öljy viedään vaarallisen jätteen keräykseen.',
            ],
            [
                'max'     => 99,
                'label'   => 'Suuri',
                'summary' => 'Sisältää puunsuoja-aineita, jotka pysyvät puussa koko sen käyttöiän.',
                'advice'  => 'Käytä hengityssuojainta ja suojakäsineitä sahatessa, äläkä hengitä pölyä. Painekyllästettyä puuta ei saa polttaa eikä kompostoida – se on vaarallista jätettä ja viedään kierrätyskeskukseen.',
            ],
        ],
    ];
}

/* ---------------------------------------------------------------
   2. Species meta box: reference price and emission factor
   --------------------------------------------------------------- */
function puupankki_calculator_meta_box() {
    add_meta_box('puupankki_laskuri_luvut', 'Laskurin luvut', 'puupankki_calculator_meta_box_html', 'puulaji', 'side');
}
add_action('add_meta_boxes', 'puupankki_calculator_meta_box');

function puupankki_calculator_meta_box_html($post) {
    wp_nonce_field('puupankki_laskuri_tallennus', 'puupankki_laskuri_nonce');
    $price        = get_post_meta($post->ID, '_pp_laskuri_hinta', true);
    $co2          = get_post_meta($post->ID, '_pp_laskuri_co2', true);
    $price_source = get_post_meta($post->ID, '_pp_laskuri_hinta_lahde', true);
    $co2_source   = get_post_meta($post->ID, '_pp_laskuri_co2_lahde', true);
    $checked      = get_post_meta($post->ID, '_pp_laskuri_tarkistettu', true);
    ?>
    <p>
        <label for="pp_laskuri_hinta">Viitehinta (€/m³, raakapuu)</label><br>
        <input type="number" id="pp_laskuri_hinta" name="pp_laskuri_hinta" min="0" step="0.01" value="<?php echo esc_attr($price); ?>">
    </p>
    <p>
        <label for="pp_laskuri_hinta_lahde">Hinnan lähde</label><br>
        <input type="text" id="pp_laskuri_hinta_lahde" name="pp_laskuri_hinta_lahde" class="widefat" placeholder="esim. K-Rauta verkkokauppa" value="<?php echo esc_attr($price_source); ?>">
    </p>
    <p>
        <label for="pp_laskuri_co2">Päästökerroin (kg CO2e/m³, raakapuu ilman kuljetusta)</label><br>
        <input type="number" id="pp_laskuri_co2" name="pp_laskuri_co2" min="0" step="0.01" value="<?php echo esc_attr($co2); ?>">
    </p>
    <p>
        <label for="pp_laskuri_co2_lahde">Päästökertoimen lähde</label><br>
        <input type="text" id="pp_laskuri_co2_lahde" name="pp_laskuri_co2_lahde" class="widefat" placeholder="esim. CO2data.fi" value="<?php echo esc_attr($co2_source); ?>">
    </p>
    <p>
        <label for="pp_laskuri_tarkistettu">Luvut tarkistettu</label><br>
        <input type="month" id="pp_laskuri_tarkistettu" name="pp_laskuri_tarkistettu" value="<?php echo esc_attr($checked); ?>">
    </p>
    <p class="description">Jos hinta tai päästökerroin on tyhjä, puulaji ei näy laskurissa. Lähteet näkyvät kävijälle laskurin info-kuvakkeen takana, joten kirjoita ne niin kuin ne saa tarkistaa.</p>
    <?php
}

function puupankki_calculator_save($post_id) {
    if (!isset($_POST['puupankki_laskuri_nonce']) || !wp_verify_nonce($_POST['puupankki_laskuri_nonce'], 'puupankki_laskuri_tallennus')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    // The meta key suffixes stay Finnish: they are database keys.
    foreach (['hinta', 'co2'] as $field) {
        $value = isset($_POST['pp_laskuri_' . $field]) ? str_replace(',', '.', $_POST['pp_laskuri_' . $field]) : '';
        if ($value === '' || !is_numeric($value)) {
            delete_post_meta($post_id, '_pp_laskuri_' . $field);
        } else {
            update_post_meta($post_id, '_pp_laskuri_' . $field, (string) floatval($value));
        }
    }

    /* Sources are free text shown to visitors, so they are stripped of tags
       and markup on the way in and escaped again on the way out. */
    foreach (['hinta_lahde', 'co2_lahde'] as $field) {
        $value = isset($_POST['pp_laskuri_' . $field]) ? sanitize_text_field(wp_unslash($_POST['pp_laskuri_' . $field])) : '';
        if ($value === '') {
            delete_post_meta($post_id, '_pp_laskuri_' . $field);
        } else {
            update_post_meta($post_id, '_pp_laskuri_' . $field, $value);
        }
    }

    // The month field gives YYYY-MM; anything else is discarded
    $checked = isset($_POST['pp_laskuri_tarkistettu']) ? sanitize_text_field(wp_unslash($_POST['pp_laskuri_tarkistettu'])) : '';
    if (preg_match('/^\d{4}-\d{2}$/', $checked)) {
        update_post_meta($post_id, '_pp_laskuri_tarkistettu', $checked);
    } else {
        delete_post_meta($post_id, '_pp_laskuri_tarkistettu');
    }
}
add_action('save_post_puulaji', 'puupankki_calculator_save');

/* ---------------------------------------------------------------
   3. Species for the calculator: only those that have both numbers
   --------------------------------------------------------------- */
function puupankki_calculator_species() {
    $species_posts = get_posts([
        'post_type'   => 'puulaji',
        'numberposts' => -1,
        'orderby'     => 'title',
        'order'       => 'ASC',
        'post_status' => 'publish',
    ]);

    $list = [];
    foreach ($species_posts as $species) {
        $price = get_post_meta($species->ID, '_pp_laskuri_hinta', true);
        $co2   = get_post_meta($species->ID, '_pp_laskuri_co2', true);
        if ($price === '' || $co2 === '') {
            continue;
        }
        /* Stored as YYYY-MM by the month field; shown to visitors as MM/YYYY */
        $checked = get_post_meta($species->ID, '_pp_laskuri_tarkistettu', true);
        if (preg_match('/^(\d{4})-(\d{2})$/', $checked, $parts)) {
            $checked = $parts[2] . '/' . $parts[1];
        } else {
            $checked = '';
        }

        $list[] = [
            'id'          => 'species-' . $species->ID,
            'label'       => $species->post_title,
            'url'         => get_permalink($species),
            'price'       => (float) $price,
            'co2'         => (float) $co2,
            'priceSource' => (string) get_post_meta($species->ID, '_pp_laskuri_hinta_lahde', true),
            'co2Source'   => (string) get_post_meta($species->ID, '_pp_laskuri_co2_lahde', true),
            'checked'     => $checked,
        ];
    }
    return $list;
}

/* ---------------------------------------------------------------
   4. Shortcode [laskurit]
   --------------------------------------------------------------- */
function puupankki_calculators_shortcode() {
    $species = puupankki_calculator_species();
    $factors = puupankki_calculator_factors();

    // Script is loaded only on the page that actually holds the calculator
    wp_enqueue_script('puupankki-calculators', get_template_directory_uri() . '/js/calculators.js', [], '2.0', true);
    wp_localize_script('puupankki-calculators', 'puupankkiCalculator', [
        'species' => $species,
        'factors' => $factors,
    ]);

    if (!$species) {
        return '<p>Laskuri tarvitsee puulajeille viitehinnan ja päästökertoimen. Lisää ne Puulajit-sisältöihin kohdassa "Laskurin luvut".</p>';
    }

    ob_start();
    ?>
    <div class="calc" id="puupankki-calculators">

        <!-- TOP: what to calculate and from what. Spans both columns, so the
             fields and the results below always start on the same line. -->
        <div class="calc__setup">

            <section class="calc__section" aria-labelledby="calc-calculators-heading">
                <h2 id="calc-calculators-heading" class="calc__heading">Valitse laskurit</h2>
                <p class="calc__hint">Voit valita useamman – ne käyttävät samoja lähtötietoja.</p>
                <div class="calc__buttons" role="group" aria-label="Laskurit">
                    <button type="button" class="calc__button is-active" data-calculator="quantity" aria-pressed="true">Materiaalimenekki</button>
                    <button type="button" class="calc__button" data-calculator="price" aria-pressed="false">Hinta-arvio</button>
                    <button type="button" class="calc__button" data-calculator="co2" aria-pressed="false">Hiilijalanjälki</button>
                    <button type="button" class="calc__button" data-calculator="chemical" aria-pressed="false">Kemikaalikuorma</button>
                </div>
            </section>

            <section class="calc__section" aria-labelledby="calc-materials-heading">
                <h2 id="calc-materials-heading" class="calc__heading">Valitse materiaalit</h2>
                <div class="calc__buttons" role="group" aria-label="Materiaalit">
                    <?php foreach ($species as $item) : ?>
                        <button type="button" class="calc__button" data-material="<?php echo esc_attr($item['id']); ?>" aria-pressed="false"><?php echo esc_html($item['label']); ?></button>
                    <?php endforeach; ?>
                </div>
            </section>

            <p class="calc__empty" id="calc-empty">Valitse vähintään yksi materiaali, niin kentät tulevat näkyviin.</p>
        </div>

        <!-- LEFT COLUMN: per-calculator panels, filled in by JavaScript -->
        <div class="calc__panels" id="calc-panels"></div>

        <!-- RIGHT COLUMN: results -->
        <section class="calc__results" id="calc-results" aria-live="polite" aria-labelledby="calc-results-heading">
            <h2 id="calc-results-heading" class="calc__heading">Tulokset</h2>
            <p class="calc__hint" id="calc-results-empty">Tulokset päivittyvät heti, kun syötät tietoja.</p>
            <div id="calc-results-body"></div>
            <p class="calc__disclaimer">Luvut ovat arvioita: hinnat ovat viitehintoja ja päästökertoimet perustuvat tyypillisiin EPD-arvoihin. Tarkista ajantasaiset luvut CO2data.fi-palvelusta ja rautakaupasta.</p>
        </section>

    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('laskurit', 'puupankki_calculators_shortcode');
