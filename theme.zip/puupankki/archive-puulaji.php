<?php
get_header();

$arkisto    = get_post_type_archive_link('puulaji');
$om_valitut = isset($_GET['om']) ? array_map('sanitize_title', (array) $_GET['om']) : [];
$kt_valitut = isset($_GET['kt']) ? array_map('sanitize_title', (array) $_GET['kt']) : [];

// Ryhmien järjestys suunnitelman mukaan
$ryhma_jarjestys = [ 'ryhma', 'hinta', 'varisavy', 'kovuus', 'paino', 'tyostettavyys' ];

$kayttotarkoitukset = get_terms([ 'taxonomy' => 'kayttotarkoitus', 'hide_empty' => false, 'orderby' => 'term_id' ]);

$sulje_ikoni = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>';
?>

<main id="content" class="container page-content">
    <h1 class="page-title">Puulajit</h1>

    <form class="puu-filters" method="get" action="<?php echo esc_url($arkisto); ?>">

        <label class="search-field">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            <span class="screen-reader-text">Hae puulajeja nimellä</span>
            <input type="search" id="puu-haku" placeholder="Hae puulajeja" autocomplete="off">
        </label>

        <p class="filter-label">Suodata hakua</p>
        <div class="filter-chips">
            <button type="button" class="chip" data-dialog="dlg-om" aria-haspopup="dialog">
                Ominaisuudet <span class="chip__count"><?php echo count($om_valitut); ?></span>
            </button>
            <button type="button" class="chip" data-dialog="dlg-kt" aria-haspopup="dialog">
                Käyttötarkoitus <span class="chip__count"><?php echo count($kt_valitut); ?></span>
            </button>
        </div>

                <?php if ($om_valitut || $kt_valitut) :

            // Palauttaa osoitteen, josta yksi suodatin on poistettu
            $poista_url = function ($avain, $slug) use ($arkisto, $om_valitut, $kt_valitut) {
                $parametrit = [
                    'om' => $avain === 'om' ? array_values(array_diff($om_valitut, [ $slug ])) : $om_valitut,
                    'kt' => $avain === 'kt' ? array_values(array_diff($kt_valitut, [ $slug ])) : $kt_valitut,
                ];
                $parametrit = array_filter($parametrit);
                return $parametrit ? $arkisto . '?' . http_build_query($parametrit) : $arkisto;
            };
            ?>

            <div class="active-filters">
                <p class="screen-reader-text">Valitut suodattimet:</p>
                <ul>
                    <?php foreach ([ 'om' => 'ominaisuus', 'kt' => 'kayttotarkoitus' ] as $avain => $taksonomia) :
                        $valitut = $avain === 'om' ? $om_valitut : $kt_valitut;

                        foreach ($valitut as $slug) :
                            $termi = get_term_by('slug', $slug, $taksonomia);
                            if (!$termi) continue;

                            // Ominaisuuksiin ryhmän nimi eteen, esim. "Kovuus: Kova"
                            $nimi = $termi->name;
                            if ($termi->parent) {
                                $ryhma = get_term($termi->parent, $taksonomia);
                                if ($ryhma && !is_wp_error($ryhma)) $nimi = $ryhma->name . ': ' . $termi->name;
                            }
                            ?>
                            <li>
                                <a class="filter-pill" href="<?php echo esc_url($poista_url($avain, $slug)); ?>">
                                    <?php echo esc_html($nimi); ?>
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                                    <span class="screen-reader-text">, poista suodatin</span>
                                </a>
                            </li>
                        <?php endforeach;
                    endforeach; ?>
                </ul>
            </div>

            <a class="clear-filters" href="<?php echo esc_url($arkisto); ?>">Tyhjennä valinnat</a>
        <?php endif; ?>

        <!-- Ominaisuudet -->
        <dialog id="dlg-om" class="filter-dialog" aria-labelledby="dlg-om-otsikko">
            <div class="dialog-inner">
                <div class="dialog-header">
                    <h2 id="dlg-om-otsikko">Ominaisuudet</h2>
                    <button type="button" class="dialog-close" data-close>
                        <?php echo $sulje_ikoni; ?><span class="screen-reader-text">Sulje</span>
                    </button>
                </div>

                <?php foreach ($ryhma_jarjestys as $ryhma_slug) :
                    $ryhma = get_term_by('slug', $ryhma_slug, 'ominaisuus');
                    if (!$ryhma) continue;
                    $vaihtoehdot = get_terms([
                        'taxonomy'   => 'ominaisuus',
                        'parent'     => $ryhma->term_id,
                        'hide_empty' => false,
                        'orderby'    => 'term_id',
                    ]);
                    ?>
                    <fieldset class="filter-group">
                        <legend><?php echo esc_html($ryhma->name); ?></legend>
                        <div class="chip-group">
                            <?php foreach ($vaihtoehdot as $termi) : ?>
                                <label class="chip-check">
                                    <input type="checkbox" name="om[]" value="<?php echo esc_attr($termi->slug); ?>" <?php checked(in_array($termi->slug, $om_valitut)); ?>>
                                    <span><?php echo esc_html($termi->name); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                <?php endforeach; ?>

                <div class="dialog-actions">
                    <button type="button" class="btn btn--secondary" data-clear>Tyhjennä valinnat</button>
                    <button type="submit" class="btn btn--primary">Näytä tulokset</button>
                </div>
            </div>
        </dialog>

        <!-- Käyttötarkoitus -->
        <dialog id="dlg-kt" class="filter-dialog" aria-labelledby="dlg-kt-otsikko">
            <div class="dialog-inner">
                <div class="dialog-header">
                    <h2 id="dlg-kt-otsikko">Käyttötarkoitus</h2>
                    <button type="button" class="dialog-close" data-close>
                        <?php echo $sulje_ikoni; ?><span class="screen-reader-text">Sulje</span>
                    </button>
                </div>

                <fieldset class="filter-group">
                    <legend class="screen-reader-text">Valitse käyttötarkoitukset</legend>
                    <div class="chip-group">
                        <?php foreach ($kayttotarkoitukset as $termi) : ?>
                            <label class="chip-check">
                                <input type="checkbox" name="kt[]" value="<?php echo esc_attr($termi->slug); ?>" <?php checked(in_array($termi->slug, $kt_valitut)); ?>>
                                <span><?php echo esc_html($termi->name); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>

                <div class="dialog-actions">
                    <button type="button" class="btn btn--secondary" data-clear>Tyhjennä valinnat</button>
                    <button type="submit" class="btn btn--primary">Näytä tulokset</button>
                </div>
            </div>
        </dialog>
    </form>

    <h2 class="screen-reader-text">Puulajit listana</h2>
    <p id="puu-maara" class="screen-reader-text" aria-live="polite"><?php echo $wp_query->found_posts; ?> puulajia</p>

    <?php if (have_posts()) : ?>
        <div class="card-list card-list--puulajit">
            <?php while (have_posts()) : the_post();
                get_template_part('template-parts/card', 'puulaji');
            endwhile; ?>
        </div>
    <?php else : ?>
        <p>Valinnoilla ei löytynyt puulajeja.</p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>