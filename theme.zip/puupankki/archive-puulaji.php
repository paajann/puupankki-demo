<?php
get_header();

$archive    = get_post_type_archive_link('puulaji');
$selected_features = isset($_GET['om']) ? array_map('sanitize_title', (array) $_GET['om']) : [];
$selected_uses = isset($_GET['kt']) ? array_map('sanitize_title', (array) $_GET['kt']) : [];

// Group order follows the design
$group_order = [ 'ryhma', 'price', 'varisavy', 'kovuus', 'paino', 'tyostettavyys' ];

$uses = get_terms([ 'taxonomy' => 'kayttotarkoitus', 'hide_empty' => false, 'orderby' => 'term_id' ]);

$close_icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>';
?>

<main id="content" class="container page-content">
    <h1 class="page-title">Puulajit</h1>

    <form class="species-filters" method="get" action="<?php echo esc_url($archive); ?>">

        <label class="search-field">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            <span class="screen-reader-text">Hae puulajeja nimellä</span>
            <input type="search" id="puu-haku" placeholder="Hae puulajeja" autocomplete="off">
        </label>

        <p class="filter-label">Suodata hakua</p>
        <div class="filter-chips">
            <button type="button" class="chip" data-dialog="dlg-om" aria-haspopup="dialog">
                Ominaisuudet <span class="chip__count"><?php echo count($selected_features); ?></span>
            </button>
            <button type="button" class="chip" data-dialog="dlg-kt" aria-haspopup="dialog">
                Käyttötarkoitus <span class="chip__count"><?php echo count($selected_uses); ?></span>
            </button>
        </div>

                <?php if ($selected_features || $selected_uses) :

            // Returns the URL with one filter removed
            $remove_url = function ($key, $slug) use ($archive, $selected_features, $selected_uses) {
                $params = [
                    'om' => $key === 'om' ? array_values(array_diff($selected_features, [ $slug ])) : $selected_features,
                    'kt' => $key === 'kt' ? array_values(array_diff($selected_uses, [ $slug ])) : $selected_uses,
                ];
                $params = array_filter($params);
                return $params ? $archive . '?' . http_build_query($params) : $archive;
            };
            ?>

            <div class="active-filters">
                <p class="screen-reader-text">Valitut suodattimet:</p>
                <ul>
                    <?php foreach ([ 'om' => 'ominaisuus', 'kt' => 'kayttotarkoitus' ] as $key => $taxonomy) :
                        $selected = $key === 'om' ? $selected_features : $selected_uses;

                        foreach ($selected as $slug) :
                            $term = get_term_by('slug', $slug, $taxonomy);
                            if (!$term) continue;

                            // Prefix features with their group, e.g. "Kovuus: Kova"
                            $name = $term->name;
                            if ($term->parent) {
                                $group = get_term($term->parent, $taxonomy);
                                if ($group && !is_wp_error($group)) $name = $group->name . ': ' . $term->name;
                            }
                            ?>
                            <li>
                                <a class="filter-pill" href="<?php echo esc_url($remove_url($key, $slug)); ?>">
                                    <?php echo esc_html($name); ?>
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                                    <span class="screen-reader-text">, poista suodatin</span>
                                </a>
                            </li>
                        <?php endforeach;
                    endforeach; ?>
                </ul>
            </div>

            <a class="clear-filters" href="<?php echo esc_url($archive); ?>">Tyhjennä valinnat</a>
        <?php endif; ?>

        <!-- Ominaisuudet -->
        <dialog id="dlg-om" class="filter-dialog" aria-labelledby="dlg-om-otsikko">
            <div class="dialog-inner">
                <div class="dialog-header">
                    <h2 id="dlg-om-otsikko">Ominaisuudet</h2>
                    <button type="button" class="dialog-close" data-close>
                        <?php echo $close_icon; ?><span class="screen-reader-text">Sulje</span>
                    </button>
                </div>

                <?php foreach ($group_order as $group_slug) :
                    $group = get_term_by('slug', $group_slug, 'ominaisuus');
                    if (!$group) continue;
                    $options = get_terms([
                        'taxonomy'   => 'ominaisuus',
                        'parent'     => $group->term_id,
                        'hide_empty' => false,
                        'orderby'    => 'term_id',
                    ]);
                    ?>
                    <fieldset class="filter-group">
                        <legend><?php echo esc_html($group->name); ?></legend>
                        <div class="chip-group">
                            <?php foreach ($options as $term) : ?>
                                <label class="chip-check">
                                    <input type="checkbox" name="om[]" value="<?php echo esc_attr($term->slug); ?>" <?php checked(in_array($term->slug, $selected_features)); ?>>
                                    <span><?php echo esc_html($term->name); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>
                <?php endforeach; ?>

                <div class="dialog-actions">
                    <button type="button" class="btn btn--secondary" data-clear>Tyhjennä valinnat</button>
                    <button type="submit" class="btn btn--primary">Näytä tulokset</button>
                </div>
            </div>
        </dialog>

        <!-- Käyttötarkoitus -->
        <dialog id="dlg-kt" class="filter-dialog" aria-labelledby="dlg-kt-otsikko">
            <div class="dialog-inner">
                <div class="dialog-header">
                    <h2 id="dlg-kt-otsikko">Käyttötarkoitus</h2>
                    <button type="button" class="dialog-close" data-close>
                        <?php echo $close_icon; ?><span class="screen-reader-text">Sulje</span>
                    </button>
                </div>

                <fieldset class="filter-group">
                    <legend class="screen-reader-text">Valitse käyttötarkoitukset</legend>
                    <div class="chip-group">
                        <?php foreach ($uses as $term) : ?>
                            <label class="chip-check">
                                <input type="checkbox" name="kt[]" value="<?php echo esc_attr($term->slug); ?>" <?php checked(in_array($term->slug, $selected_uses)); ?>>
                                <span><?php echo esc_html($term->name); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>

                <div class="dialog-actions">
                    <button type="button" class="btn btn--secondary" data-clear>Tyhjennä valinnat</button>
                    <button type="submit" class="btn btn--primary">Näytä tulokset</button>
                </div>
            </div>
        </dialog>
    </form>

    <h2 class="screen-reader-text">Puulajit listana</h2>
    <p id="puu-maara" class="screen-reader-text" aria-live="polite"><?php echo $wp_query->found_posts; ?> puulajia</p>

    <?php if (have_posts()) : ?>
        <div class="card-list card-list--species">
            <?php while (have_posts()) : the_post();
                get_template_part('template-parts/card', 'puulaji');
            endwhile; ?>
        </div>
    <?php else : ?>
        <p>Valinnoilla ei löytynyt puulajeja.</p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>