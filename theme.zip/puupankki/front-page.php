<?php get_header(); ?>

<main id="content">

    <?php while (have_posts()) : the_post(); ?>
    <section class="hero">
        <?php if (has_post_thumbnail()) the_post_thumbnail('full', [ 'class' => 'hero__image', 'alt' => '' ]); ?>
        <div class="hero__text">
            <?php the_content(); ?>
        </div>
    </section>
    <?php endwhile; ?>

    <?php
    $posts = new WP_Query([ 'post_type' => 'post', 'posts_per_page' => 2 ]);
    $projects  = new WP_Query([ 'post_type' => 'projekti', 'posts_per_page' => 6 ]);
    $videos     = new WP_Query([ 'post_type' => 'video', 'posts_per_page' => 1 ]);
    ?>

    <div class="container">
                <section class="front-section calc-teaser" aria-labelledby="otsikko-laskurit">
            <div>
                <h2 id="otsikko-laskurit">Laskurit</h2>
                <?php
                /* The calculator page is found by its slug, so the links stay
                   correct even if the page is renamed. The ?laskuri= value
                   preselects that one calculator on arrival. */
                $calculators_page = get_page_by_path('laskurit');
                $calculators_url  = $calculators_page ? get_permalink($calculators_page) : home_url('/laskurit/');
                $calculator_links = [
                    'tarve'      => 'Materiaalimenekki',
                    'hinta'      => 'Hinta-arvio',
                    'co2'        => 'Hiilijalanjälki',
                    'kemikaalit' => 'Kemikaalikuorma',
                ];
                ?>
                <ul class="calc-buttons">
                    <?php foreach ($calculator_links as $key => $label) : ?>
                        <li><a class="calc-button" href="<?php echo esc_url(add_query_arg('laskuri', $key, $calculators_url)); ?>"><?php echo esc_html($label); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="calc-teaser__text">
                <h3><?php echo esc_html(get_theme_mod('puupankki_laskurit_otsikko', 'Laskurit suunnittelun tueksi')); ?></h3>
                <p><?php echo esc_html(get_theme_mod('puupankki_laskurit_teksti', 'Laskurit auttavat arvioimaan projektin materiaalit ennen kuin tartut sahaan. Materiaalimenekki kertoo, paljonko puuta tarvitset, ja laskureita voi käyttää myös yhdessä – samalla kertaa näet menekin, hinnan ja hiilijalanjäljen.')); ?></p>
            </div>
        </section>

        <div class="front-columns">

            <section class="front-section" aria-labelledby="otsikko-artikkelit">
                <div class="section-header">
                    <h2 id="otsikko-artikkelit">Uusimmat artikkelit</h2>
                    <a class="see-all" href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>">Katso kaikki<span class="screen-reader-text"> artikkelit</span></a>
                </div>
                <div class="card-list">
                    <?php if ($posts->have_posts()) :
                        while ($posts->have_posts()) : $posts->the_post();
                            get_template_part('template-parts/card', 'article');
                        endwhile;
                        wp_reset_postdata();
                    else : ?>
                        <p>Ei vielä artikkeleita.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="front-section" aria-labelledby="otsikko-projektit">
                <div class="section-header">
                    <h2 id="otsikko-projektit">Inspiroivat projektit</h2>
                    <a class="see-all" href="<?php echo esc_url(get_post_type_archive_link('projekti')); ?>">Katso kaikki<span class="screen-reader-text"> projektit</span></a>
                </div>
                <div class="card-list card-list--scroll">
                    <?php if ($projects->have_posts()) :
                        while ($projects->have_posts()) : $projects->the_post();
                            get_template_part('template-parts/card', 'projekti');
                        endwhile;
                        wp_reset_postdata();
                    else : ?>
                        <p>Ei vielä projekteja.</p>
                    <?php endif; ?>
                </div>
                                <div class="carousel-controls">
                    <button class="carousel-btn carousel-prev" type="button">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
                        <span class="screen-reader-text">Edellinen projekti</span>
                    </button>
                    <div class="carousel-dots" aria-hidden="true"></div>
                    <button class="carousel-btn carousel-next" type="button">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
                        <span class="screen-reader-text">Seuraava projekti</span>
                    </button>
                </div>
            </section>

        </div>

        <section class="front-section" aria-labelledby="otsikko-videot">
            <div class="section-header">
                <h2 id="otsikko-videot">Kiinnostavat video-ohjeet</h2>
                <a class="see-all" href="<?php echo esc_url(get_post_type_archive_link('video')); ?>">Katso kaikki<span class="screen-reader-text"> video-ohjeet</span></a>
            </div>
            <div class="card-list card-list--video">
                <?php if ($videos->have_posts()) :
                    while ($videos->have_posts()) : $videos->the_post();
                        get_template_part('template-parts/card', 'video');
                    endwhile;
                    wp_reset_postdata();
                else : ?>
                    <p>Ei vielä video-ohjeita.</p>
                <?php endif; ?>
            </div>
        </section>

        <?php if (is_active_sidebar('etusivu-nostot')) dynamic_sidebar('etusivu-nostot'); ?>

    </div>
</main>

<?php get_footer(); ?>