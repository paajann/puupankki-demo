<?php
get_header();

// Liikkeet ovat samat kaikille puulajeille (esimerkkidataa)
$stores = [
    'kouvola' => [ 'name' => 'Kouvola', 'liikkeet' => [ 'Byggmax Kouvola', 'K-Rauta Kouvola', 'Stark Kouvola' ] ],
    'lahti'   => [ 'name' => 'Lahti',   'liikkeet' => [ 'Bauhaus Lahti', 'Byggmax Lahti', 'K-Rauta Lahti', 'Stark Lahti' ] ],
    'porvoo'  => [ 'name' => 'Porvoo',  'liikkeet' => [ 'K-Rauta Porvoo', 'Stark Porvoo' ] ],
];
$default_city = 'lahti';

// Fact table rows in the order set by the design
$group_order = [ 'ryhma', 'price', 'varisavy', 'kovuus', 'paino', 'tyostettavyys' ];

$projects = new WP_Query([ 'post_type' => 'projekti', 'posts_per_page' => 6 ]);
?>

<main id="content" class="container page-content">
<?php while (have_posts()) : the_post();

    // Collect the species features by group, e.g. [ 'Kovuus' => 'Kova' ]
    $details = [];
    $terms = get_the_terms(get_the_ID(), 'ominaisuus');
    if ($terms && !is_wp_error($terms)) {
        foreach ($group_order as $group_slug) {
            $group = get_term_by('slug', $group_slug, 'ominaisuus');
            if (!$group) continue;
            $values = [];
            foreach ($terms as $term) {
                if ($term->parent === $group->term_id) $values[] = $term->name;
            }
            if ($values) $details[$group->name] = implode(', ', $values);
        }
    }

        $has_acf = function_exists('get_field');
    if ($has_acf && get_field('saatavuus')) {
        $details['Saatavuus'] = get_field('saatavuus');
    }

    // Accordions: heading => content
    $accordions = [
        'Kuvaus'                         => apply_filters('the_content', get_the_content()),
                'Käyttökohteet'                  => $has_acf ? get_field('kayttokohteet') : '',
        'Huomioitavaa'                   => $has_acf ? get_field('huomioitavaa') : '',
        'Jalostetut rakennusmateriaalit' => $has_acf ? get_field('jalostetut') : '',
    ];
    ?>

    <article class="puu">
        <a class="back-link" href="<?php echo esc_url(get_post_type_archive_link('puulaji')); ?>">Kaikki puulajit</a>

               <?php
        // Gallery: featured image plus the extra ACF images
        $images = [];
        if (has_post_thumbnail()) {
            $images[] = get_post_thumbnail_id();
        }
        if ($has_acf) {
            foreach ([ 'lisakuva_1', 'lisakuva_2', 'lisakuva_3' ] as $field) {
                $image_id = get_field($field);
                if ($image_id) $images[] = $image_id;
            }
        }
        ?>

        <?php if ($images) : ?>
            <div class="species__gallery">
                <div class="gallery" tabindex="0" role="region" aria-label="Kuvat: <?php the_title_attribute(); ?>">
                    <?php foreach ($images as $image_id) : ?>
                        <figure class="gallery__item">
                            <?php echo wp_get_attachment_image($image_id, 'large'); ?>
                        </figure>
                    <?php endforeach; ?>
                </div>
                <div class="carousel-controls">
                    <button class="carousel-btn carousel-prev" type="button">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
                        <span class="screen-reader-text">Edellinen kuva</span>
                    </button>
                    <div class="carousel-dots" aria-hidden="true"></div>
                    <button class="carousel-btn carousel-next" type="button">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
                        <span class="screen-reader-text">Seuraava kuva</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>

        <h1 class="species__title"><?php the_title(); ?></h1>

        <?php if (has_excerpt()) : ?>
            <p class="species__intro"><?php echo esc_html(get_the_excerpt()); ?></p>
        <?php endif; ?>

        <?php if ($details) : ?>
            <dl class="species__facts">
                <?php foreach ($details as $title => $value) : ?>
                    <div>
                        <dt><?php echo esc_html($title); ?></dt>
                        <dd><?php echo esc_html($value); ?></dd>
                    </div>
                <?php endforeach; ?>
            </dl>
        <?php endif; ?>

        <div class="accordion">
            <?php foreach ($accordions as $title => $content) :
                if (!trim(wp_strip_all_tags((string) $content))) continue; ?>
                <details>
                    <summary><h2><?php echo esc_html($title); ?></h2></summary>
                    <div class="accordion__content"><?php echo wp_kses_post($content); ?></div>
                </details>
            <?php endforeach; ?>
        </div>

        <section class="stores" aria-labelledby="otsikko-liikkeet">
            <div class="stores__text">
                <h2 id="otsikko-liikkeet">Katso puuta myyvät liikkeet</h2>

                <label class="screen-reader-text" for="kaupunki">Valitse kaupunki</label>
                <select id="kaupunki" class="stores__select">
                    <?php foreach ($stores as $slug => $city) : ?>
                        <option value="<?php echo esc_attr($slug); ?>" <?php selected($slug, $default_city); ?>>
                            <?php echo esc_html($city['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <div class="stores__lists" aria-live="polite">
                    <?php foreach ($stores as $slug => $city) : ?>
                        <ul class="stores__list" data-city="<?php echo esc_attr($slug); ?>" <?php if ($slug !== $default_city) echo 'hidden'; ?>>
                            <?php foreach ($city['liikkeet'] as $store) : ?>
                                <li>
                                    <a href="<?php echo esc_url('https://www.google.com/maps/search/?api=1&query=' . rawurlencode($store)); ?>" target="_blank" rel="noopener">
                                        <?php echo esc_html($store); ?>
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
                                        <span class="screen-reader-text">(avautuu Google Mapsiin uuteen välilehteen)</span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="stores__map">
                <?php echo do_shortcode('[wpgmza id="1"]'); ?>
            </div>
        </section>
    </article>

<?php endwhile; ?>

    <?php if ($projects->have_posts()) : ?>
    <section class="front-section species__projects" aria-labelledby="otsikko-projektit">
        <div class="section-header">
            <h2 id="otsikko-projektit">Inspiroivat projektit</h2>
            <a class="see-all" href="<?php echo esc_url(get_post_type_archive_link('projekti')); ?>">Katso kaikki<span class="screen-reader-text"> projektit</span></a>
        </div>
        <div class="card-list card-list--scroll">
            <?php while ($projects->have_posts()) : $projects->the_post();
                get_template_part('template-parts/card', 'projekti');
            endwhile; wp_reset_postdata(); ?>
        </div>
        <div class="carousel-controls">
            <button class="carousel-btn carousel-prev" type="button">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
                <span class="screen-reader-text">Edellinen projekti</span>
            </button>
            <div class="carousel-dots" aria-hidden="true"></div>
            <button class="carousel-btn carousel-next" type="button">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
                <span class="screen-reader-text">Seuraava projekti</span>
            </button>
        </div>
    </section>
    <?php endif; ?>
</main>

<?php get_footer(); ?>